"""Run the full evaluation: ingest → basic RAG vs routed Advanced RAG → report."""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from advanced_rag.config import INDEX_DIR, OUTPUT_DIR
from advanced_rag.cost import CostTracker
from advanced_rag.evaluate import evaluate_answer
from advanced_rag.ingest import Chunk, ingest
from advanced_rag.llm import LLMClient, check_ollama_models
from advanced_rag.pipeline import RAGPipeline
from advanced_rag.questions import QUESTIONS
from advanced_rag.reporting import write_outputs
from advanced_rag.store import VectorStore


def pack_row(qid: str, focus: str, reference: str, result: dict, metrics: dict) -> dict:
    return {
        "id": qid,
        "focus": focus,
        "question": result["question"],
        "route": result["route"],
        "reason": result.get("reason"),
        "techniques": result.get("techniques") or [],
        "executed": result.get("executed") or [],
        "retrieved_ids": result.get("retrieved_ids") or [],
        "retrieved_sources": result.get("retrieved_sources") or [],
        "context": result.get("context") or "",
        "answer": result.get("answer") or "",
        "notes": result.get("notes") or {},
        "reference": reference,
        "metrics": metrics,
        "cost": result.get("cost") or {},
    }


def main() -> None:
    force_reingest = os.getenv("FORCE_REINGEST", "0").strip() not in ("0", "", "false", "False")
    chunks_path = INDEX_DIR / "chunks.json"
    if chunks_path.exists() and not force_reingest:
        print(f"Found existing index at {chunks_path} -- skipping ingest/OCR (set FORCE_REINGEST=1 to rebuild).")
        raw = json.loads(chunks_path.read_text(encoding="utf-8"))
        chunks = [Chunk(**row) for row in raw]
    else:
        print("Ingesting PDFs...")
        chunks = ingest()
    print(f"Indexed {len(chunks)} chunks from {len({c.source for c in chunks})} manuals")
    llm = LLMClient()
    print(
        f"LLM backend: {llm.model} "
        f"(openrouter={getattr(llm, 'use_openrouter', False)}, "
        f"claude={llm.use_claude}, ollama={llm.use_ollama}, gemini={llm.use_gemini})"
    )
    if llm.use_ollama:
        print(f"  generation model: {llm.model}")
        print(f"  judge model:      {llm.judge_model}  (separate weights, avoids self-grading bias)")
    # Fail fast with a specific diagnosis instead of burning through the
    # whole eval on calls that will all 404 -> fall back silently. See
    # check_ollama_models() in llm.py for what this actually checks.
    if llm.use_claude:
        print("[preflight] Claude is PRIMARY — Ollama check is optional (fallback only).")
        try:
            check_ollama_models(llm)
        except Exception as exc:
            print(f"[preflight] Ollama optional check skipped: {exc}")
    else:
        check_ollama_models(llm)
    store = VectorStore.build(llm)
    pipeline = RAGPipeline(store, llm)

    advanced_rows = []
    pipeline.reset_history()
    print("\n=== Routed / Advanced path ===")
    for item in QUESTIONS:
        print(f"Running {item['id']}: {item['question'][:80]}")
        result = pipeline.run(item["question"])
        tracker = CostTracker()
        metrics = evaluate_answer(
            item["question"],
            result.get("context") or "",
            result.get("answer") or "",
            item["reference"],
            result["route"],
            llm,
            tracker,
        )
        if tracker.calls:
            result["cost"]["judge"] = tracker.breakdown()
        row = pack_row(item["id"], item["focus"], item["reference"], result, metrics)
        advanced_rows.append(row)
        print(
            f"  route={result['route']} techniques={result['techniques']} "
            f"cost=${result['cost']['total_cost_usd']:.6f} lat={result['cost']['wall_latency_s']:.2f}s"
        )

    basic_rows = []
    pipeline.reset_history()
    print("\n=== Basic RAG baseline (forced) ===")
    for item in QUESTIONS:
        print(f"Baseline {item['id']}")
        result = pipeline.run_basic_only(item["question"])
        tracker = CostTracker()
        metrics = evaluate_answer(
            item["question"],
            result.get("context") or "",
            result.get("answer") or "",
            item["reference"],
            result["route"],
            llm,
            tracker,
        )
        row = pack_row(item["id"], item["focus"], item["reference"], result, metrics)
        basic_rows.append(row)

    write_outputs(advanced_rows, basic_rows)
    (OUTPUT_DIR / "route_decisions.json").write_text(
        json.dumps(
            [
                {"id": r["id"], "route": r["route"], "reason": r["reason"], "techniques": r["techniques"]}
                for r in advanced_rows
            ],
            indent=2,
        ),
        encoding="utf-8",
    )
    (OUTPUT_DIR / "cost_breakdown.json").write_text(
        json.dumps({r["id"]: r["cost"] for r in advanced_rows}, indent=2),
        encoding="utf-8",
    )
    print(f"\nWrote reports to {OUTPUT_DIR} and {INDEX_DIR.parent.parent / 'reports'}")


if __name__ == "__main__":
    main()
