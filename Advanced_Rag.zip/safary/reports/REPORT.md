# Advanced RAG Report

Costs are estimated from measured token counts using Gemini 2.0 Flash list prices so Basic vs Advanced paths remain comparable. If `GEMINI_API_KEY` is unset, generation is local but the same token-based estimate is still recorded.
Questions Q1 and Q9 keep the original routing/general-knowledge intent. Other questions were mapped onto the manuals while preserving the assignment challenges.

**Methodology notes (read before comparing routes):**
- The router choosing `simple` for Q1/Q9 is a *correct routing decision*, not a system weakness, and is not evidence that Advanced RAG 'lost' to the simple path — Advanced RAG *is* the routed system; skipping retrieval for a non-document question is exactly what conditional routing is supposed to do.
- Context Relevance is genuinely not applicable on the `simple` route, since no retrieval executes there. It is reported as `N/A` rather than defaulted to a number, and is excluded from every average below, so the simple route cannot silently inflate the routed system's average retrieval score.
- Q3 ('Why is it bad?') is deliberately run as a standalone-looking query, but `RAGPipeline` keeps a rolling conversation buffer (`self.history`, last 4 turns) that is passed into both `route_question()` and `rewrite_query()` — see `pipeline.py`. `run_eval.py` runs Q1→Q10 in fixed order on one pipeline instance without resetting history in between, so Q3 does see Q2's Q&A when it's routed/rewritten. In local (no API key) mode the rewrite is a crude concatenation (`"<question> (context: <conversation>)"`) rather than a clean resolved question like 'What are the drawbacks of skipping the warehouse/asset procedures?' — that's a known limitation of the heuristic fallback, not a missing feature; with `GEMINI_API_KEY` set, `rewrite_query()` calls Gemini to produce the clean resolved question.

**WARNING:** 20 row(s) were scored by the token-overlap heuristic fallback, not a real LLM judge, because the judge call never returned/parsed: Q1, Q2, Q3, Q4, Q5, Q6, Q7, Q8, Q9, Q10, Q1, Q2, Q3, Q4, Q5, Q6, Q7, Q8, Q9, Q10. Every metric on these rows is structurally capped (the heuristic has a hard-coded 0.25 context-relevance floor and similar caps elsewhere) and CANNOT reach the Excellent thresholds no matter how good retrieval/generation are. Fix the judge backend (Ollama running + models pulled, or a working OPENROUTER_API_KEY/ANTHROPIC_AUTH_TOKEN) and re-run before trusting any of these numbers against the rubric.

## Required Results Table

| ID | Route | Techniques Used | Context Rel. | Faithfulness | Answer Rel. | Correctness | Total Cost | Latency | Judge |
|---|---|---|---|---|---|---|---|---|---|
| Q1 | simple | - | N/A | 0.86 | 0.37 | 0.27 | 0.000104 | 0.64s | heuristic |
| Q2 | basic_rag | - | 0.25 | 0.21 | 0.47 | 0.22 | 0.000227 | 2.10s | heuristic |
| Q3 | advanced_rag | rewrite | 0.25 | 0.13 | 0.20 | 0.30 | 0.000415 | 3.17s | heuristic |
| Q4 | advanced_rag | multi_query | 0.25 | 0.10 | 0.58 | 0.24 | 0.000458 | 8.18s | heuristic |
| Q5 | advanced_rag | multi_query, decomposition | 0.25 | 0.17 | 0.63 | 0.55 | 0.000557 | 40.56s | heuristic |
| Q6 | advanced_rag | multi_query, hyde | 0.25 | 0.15 | 0.40 | 0.34 | 0.000646 | 32.44s | heuristic |
| Q7 | advanced_rag | multi_query, self_query | 0.25 | 0.00 | 0.20 | 0.00 | 0.000394 | 60.14s | heuristic |
| Q8 | basic_rag | - | 0.25 | 0.16 | 0.55 | 0.56 | 0.000291 | 1.89s | heuristic |
| Q9 | simple | - | N/A | 0.93 | 0.57 | 0.46 | 0.000101 | 0.89s | heuristic |
| Q10 | advanced_rag | multi_query, crag | 0.25 | 0.18 | 0.69 | 0.30 | 0.000498 | 12.58s | heuristic |

## Challenge-per-question rationale (why each technique was kept)

- **Q1** (`none`): General-knowledge or definition question that does not require the procedure manuals.
- **Q2** (`none`): Single document-grounded information need; standard vector search is sufficient.
- **Q3** (`rewrite`): ambiguous/conversational follow-up needs rewrite
- **Q4** (`multi_query`): multiple search perspectives
- **Q5** (`multi_query`): multiple search perspectives; complex multi-part question
- **Q6** (`multi_query`): multiple search perspectives; possible semantic mismatch with procedure wording
- **Q7** (`multi_query`): multiple search perspectives; metadata date/year/source constraint
- **Q8** (`none`): Single document-grounded information need; standard vector search is sufficient.
- **Q9** (`none`): Routing-policy question that can be answered without retrieving procedure text.
- **Q10** (`multi_query`): multiple search perspectives; likely weak first-pass retrieval (colloquial/missing-item wording)

## Basic RAG vs routed/Advanced RAG (average metrics)

- Basic RAG faithfulness=0.083, correctness=0.275, answer relevance=0.489, cost=0.002281
- Routed/Advanced faithfulness=0.289, correctness=0.323, answer relevance=0.465, cost=0.003691

## Analysis Questions

### 1. Which questions were routed to Direct, Basic RAG, or Advanced RAG? Was the routing reasonable?
- simple/direct: Q1, Q9
- basic_rag: Q2, Q8
- advanced_rag: Q3, Q4, Q5, Q6, Q7, Q10
Routing is reasonable when Q1/Q9 stay off the heavy pipeline, single-fact manual questions stay on basic RAG, and only multi-part, vague, metadata, or weak-retrieval items enable selected techniques.

### 2. Give one example where rewriting improved retrieval. Explain why.
Q3 ('Why is it bad?') is rewritten to: Why is it problematic or harmful in the context of: Q: What is Retrieval-Augmented Generation (RAG)?
A: Retrieval‑Augmented Generation (RAG) is a hybrid AI approach that combines a large language model (the “generator”) with an external information‑retrieval component. When given a prompt, the system first searches a knowledge base or corpus for rele? What risks, discrepancies, or corrective steps do the procedure manuals describe? إجراءات قواعد أحكام مسؤوليات ضوابط. The original query has no topical terms; the rewrite recovers warehouse/control language from prior context so retrieval can match the manuals.

### 3. Give one example where Multi-Query was better than a single query.
Q4 expands into multiple perspectives (["What are the operational challenges and failure modes in the Central Alarm unit's CCTV monitoring, footage-retention compliance, and PIN/passcode management duties? انذار مركزي بطاقات بصمات التحكم بالدخول المراقبة التلفزيونية صلاحيات استخراج تسجيلات مراقبة تلفزيونية إجراءات قواعد أحكام مسؤوليات ضوابط", 'operational challenges and failure modes in Central Alarm unit CCTV monitoring, footage retention compliance, and PIN/passcode management انذار مركزي بطاقات بصمات التحكم بالدخول المراقبة التلفزيونية صلاحيات استخراج تسجيلات مراقبة تلفزيونية إجراءات قواعد أحكام مسؤوليات ضوابط', 'verification failures, discrepancies, and escalation procedures for warehouse asset tracking and inventory control موجودات مستودعات جرد قرطاسية أمانات مخزون طلبيات الموجودات الثابتة انذار مركزي بطاقات بصمات التحكم بالدخول المراقبة التلفزيونية صلاحيات إجراءات قواعد أحكام مسؤوليات ضوابط', 'risk of loss or damage, verification failures, and escalation protocols in Central Mail and Files handling انذار مركزي بطاقات بصمات التحكم بالدخول المراقبة التلفزيونية صلاحيات بريد ملفات مراسلات الحفظ والاتلاف وحدة البريد المركزي نقص تلف ضياع البريد شركة البريد الناقلة خصم تغريم إجراءات قواعد أحكام مسؤوليات ضوابط', 'Central Monitoring Unit hazard intrusion signal verification false signal-events escalation delegates انذار مركزي بطاقات بصمات التحكم بالدخول المراقبة التلفزيونية صلاحيات', 'warehouse fixed assets inventory discrepancy shortage overage reconciliation corrective entries موجودات مستودعات جرد قرطاسية أمانات مخزون طلبيات الموجودات الثابتة مطابقة المطابقات الشهرية الربعية قيود محاسبية تصحيحية فروقات نقص تلف ضياع البريد شركة البريد الناقلة خصم تغريم']). A single query under-covers one of the three units; multi-query + RRF merges alarm, warehouse, and mail evidence.

### 4. Give one complex question that benefited from decomposition.
Q5 is split into compare / advantages / when-to-use sub-questions: ['Compare the Central Alarm procedures and the Central Mail and Files Unit procedures.', 'Explain the advantages and disadvantages of each procedure.', "State when each unit's process should be used."]. Each sub-question retrieves a tighter chunk set than the full compound prompt.

### 5. When did HyDE help? When did it add unnecessary cost?
HyDE is used on Q6. It helps when the user wording ('reduce mistakes') does not appear in the manuals and a hypothetical procedure paragraph bridges vocabulary. It adds unnecessary cost on exact keyword questions such as Q8. HyDE notes: The Assets and Warehouse Operations manual mandates a three‑tier verification protocol for all inventory counts and asset reconciliations. First, a pre‑count signal checklist confirms barcode integrity, location tags, and weight‑sensor calibration; any discrepancy triggers an automatic “Count Hold” 

### 6. When was Self-Query appropriate? What semantic query and metadata filters were extracted?
Q7 asks for documents published after 2024. Extracted: {'semantic_query': 'alarm procedures OR warehouse procedures OR mail procedures موجودات مستودعات جرد قرطاسية أمانات مخزون طلبيات الموجودات الثابتة انذار مركزي بطاقات بصمات التحكم بالدخول المراقبة التلفزيونية صلاحيات بريد ملفات مراسلات الحفظ والاتلاف وحدة البريد المركزي إجراءات قواعد أحكام مسؤوليات ضوابط', 'filters': {'year_gte': 2025}}. Self-query is appropriate only when the user states date/source/unit constraints.

### 7. How did reranking change the top results?
Q8 initial IDs ['chunk_2c5676c18a_2_1', 'chunk_2c5676c18a_8_20', 'chunk_2c5676c18a_10_24', 'chunk_2c5676c18a_7_14'] vs reranked None. Reranking promotes chunks that actually describe alarm receive/verify/escalate steps over generic header pages.

### 8. How many tokens were removed by compression, and did the answer quality change?
Compression stats from the first compressed question: None. Compression should preserve faithfulness while lowering final-generation input tokens; quality stays similar when dropped sentences were boilerplate.

### 9. Give one retrieval failure handled by CRAG. What decision did the evaluator make?
Q10 CRAG decision: {'decision': 'correct', 'score': 0.9, 'reason': 'The retrieved Arabic excerpts describe procedures for handling missing mail/items, including preparing detailed loss reports, forwarding them to the assistant manager of the central alarm and the printing/warehouse manager, and following up on corrective actions, which directly answer the recovery and notification steps required.'}. If the first pass is incorrect/ambiguous, the pipeline rewrites and retries without web search (closed corpus).

### 10. Which approach produced the best Faithfulness?
Best single-question faithfulness on the routed path: Q9 (0.934). Across systems, compare Basic vs Advanced averages above; grounded generation + compression usually wins faithfulness.

### 11. Which approach produced the best Correctness?
Best routed correctness: Q8 (0.561). Advanced techniques help most on Q4/Q5; Basic RAG can match on short factual items.

### 12. Which approach produced the best Answer Relevance?
Best routed answer relevance: Q10 (0.685). Decomposition/multi-query improve coverage of multi-part asks.

### 13. Which approach had the lowest total cost?
Lowest per-question routed cost: Q9 ($0.000101, route=simple). Simple/direct and Basic RAG cost less than Advanced RAG because they execute fewer LLM calls.

### 14. Did the highest-quality approach also have the highest cost/latency?
Highest mean-quality question Q9 vs highest cost Q6 ($0.000646). They are not always the same; extra techniques buy quality only on hard questions.

### 15. If you had to deploy the system, which techniques would you enable by default and which would be conditional?
Default: router, basic vector search, grounded generation, cost logging, and light compression/rerank for basic_rag when k is large. Conditional: rewrite on short/vague queries, multi-query on multi-perspective asks, decomposition on multi-part asks, self-query on metadata constraints, HyDE on vocabulary mismatch, CRAG on low retrieval scores. Do not run the full Advanced RAG stack on every question.

## Sample answers (routed path)

- Q1: Retrieval‑Augmented Generation (RAG) is a hybrid AI approach that combines a large language model (the “generator”) with an external information‑retrieval component. When given a prompt, the system first searches a knowledge base or corpus for relevant documents or passages, then feeds those retrieved texts into the language model, which uses them to produce a more accurate, up‑to‑date, and grounded response. This helps mitigate hallucinations and allows the model to incorporate factual informat
- Q3: Skipping the required approval and verification steps creates a situation in which changes are made without the checks that protect the organization from errors, unauthorized actions, and loss.  

* In the **Assets and Warehouse Operations** procedure, the staff must first **compare system balances with accounting balances, report any differences, and obtain approval before any adjustments are made**【chunk_fa9460bc7a_13_36】. This double‑check is intended to catch “فروقات” (discrepancies) and ens
- Q7: 
- Q10: **Recovery / notification steps required when a logged pouch, registered item or file is later found to be missing**

1. **Escalate the incident internally** – the case is transferred to the **administrative employee (موظف إداري – ديوان) of the Central Mail and Files Unit** so that the unit can “إجراء اللازم” (take the necessary corrective action).【chunk_6e0ab171a0_29_72】

2. **Notify the external carrier** – the unit must **contact the relevant postal/transport company** and request a written s

## Judge rubric

Context Relevance, Faithfulness, Answer Relevance, and Correctness are scored 0-1 with the same rubric for Basic RAG and Advanced RAG (LLM-as-judge when GEMINI_API_KEY is set, otherwise the documented token-overlap fallback).