"""Ask the pipeline any question — not just the fixed Q1-Q10 evaluation set.

This exists to let you sanity-check how the system handles TA-style
questions it has never seen, using the exact same RAGPipeline (router ->
retrieval -> generation) that run_eval.py uses. It does NOT run the judge/
evaluation step (no reference answer to score against for an ad-hoc
question) — it just shows you the routing decision, retrieved sources,
and generated answer.

Every result is ALSO written to a plain UTF-8 .txt file under outputs/ —
not just printed to the terminal. VS Code's integrated terminal is known
to mangle/reverse right-to-left (Arabic) text; opening the .txt file in
Notepad (or VS Code's own file editor, NOT its terminal) renders it
correctly.

Usage:
    python ask.py "How does the mail unit handle a lost registered item?"
        -> single question, prints + saves to outputs/ask_last_result.txt

    python ask.py --basic "..."
        -> same, but forces the basic_rag baseline route (skips all
           advanced techniques), same as run_eval.py's baseline pass

    python ask.py --file manual_test_questions.txt
        -> batch mode: one question per line (blank lines and lines
           starting with # are skipped/kept as section headers in the
           report). Runs every question through the SAME pipeline
           instance in order, so conversation history carries over line
           to line (needed for rewrite-style follow-up questions like
           "why is it bad?" right after the question it refers to).
           Saves one combined report to outputs/ask_batch_<timestamp>.txt

    python ask.py --file manual_test_questions.txt --basic
        -> same batch, but every question forced through basic_rag, for
           an apples-to-apples comparison against the routed run

    python ask.py
        -> interactive prompt loop (still saves everything to
           outputs/ask_last_result.txt as you go)
"""

from __future__ import annotations

import datetime as _dt
import sys
from pathlib import Path

from advanced_rag.config import INDEX_DIR
from advanced_rag.ingest import ingest
from advanced_rag.llm import LLMClient
from advanced_rag.pipeline import RAGPipeline
from advanced_rag.store import VectorStore

OUTPUT_DIR = Path(__file__).resolve().parent / "outputs"

# FIX (mojibake / box-drawing characters when piping stdout to a file on
# Windows): Python's stdout on a Windows console defaults to the legacy
# OEM/ANSI codepage, not UTF-8. print()-ing Arabic then redirecting with
# PowerShell's `>` double-encodes it (bytes get encoded once by Python in
# the wrong codepage, then re-encoded again by PowerShell's Out-File),
# producing garbage like "╚غ╟┴≡". This does NOT affect the auto-saved
# outputs/*.txt files below — those are opened and written directly with
# an explicit encoding, independent of stdout — but it's worth forcing
# stdout itself to UTF-8 too, so a live, non-redirected terminal that
# happens to support UTF-8 (most modern Windows Terminal / PowerShell 7)
# also displays correctly instead of raising or mangling.
try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass


def _format_result(question: str, result: dict) -> str:
    lines = [f"Q: {question}", ""]
    lines.append(f"route:      {result['route']}")
    lines.append(f"techniques: {result['techniques']}")
    lines.append(f"reason:     {result.get('reason')}")
    lines.append(f"executed:   {result.get('executed')}")
    sources = result.get("retrieved_sources") or []
    if sources:
        lines.append("retrieved:")
        for s in sources:
            lines.append(f"  [{s['chunk_id']}] {s['source']} p.{s['page']} (score={s['score']:.3f})")
    else:
        lines.append("retrieved:  (none — parametric/general-knowledge answer)")
    cost = result.get("cost") or {}
    lines.append(
        f"cost:       ${cost.get('total_cost_usd', 0):.6f}  "
        f"latency={cost.get('wall_latency_s', 0):.2f}s"
    )
    lines.append("")
    lines.append("answer:")
    lines.append(result["answer"])
    lines.append("")
    lines.append("-" * 70)
    return "\n".join(lines)


def _write(path: Path, text: str, append: bool = False) -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    # utf-8-sig: plain "utf-8" renders fine in modern Notepad too, but the
    # BOM makes older Notepad/Excel auto-detect Arabic correctly as well,
    # so there's no reason not to include it.
    mode = "a" if append else "w"
    with open(path, mode, encoding="utf-8-sig", newline="\n") as f:
        f.write(text)
        f.write("\n")


def main() -> None:
    args = sys.argv[1:]
    force_basic = False
    if "--basic" in args:
        force_basic = True
        args = [a for a in args if a != "--basic"]

    batch_file: Path | None = None
    if args and args[0] == "--file":
        batch_file = Path(args[1])
        args = args[2:]

    print("Loading index / models (same as run_eval.py)...")
    # Only (re-)ingest if the on-disk index is actually missing. Otherwise
    # reuse the existing chunks.json / bm25.pkl / embeddings.npy under
    # data/index/ so every ask.py question is fast instead of re-running
    # OCR on all 3 PDFs from scratch every single time. VectorStore.load()
    # below already has this same "load if present, else build" check
    # built in — this just avoids the (slow, OCR-heavy) unconditional
    # ingest() call that used to run before load() ever got a chance to
    # look.
    chunks_path = INDEX_DIR / "chunks.json"
    bm25_path = INDEX_DIR / "bm25.pkl"
    if not chunks_path.exists() or not bm25_path.exists():
        print("[ask] Index not found — running ingest once...")
        ingest()
    else:
        print("[ask] Using existing index (skipping ingest).")
    llm = LLMClient()
    store = VectorStore.load(llm)
    pipeline = RAGPipeline(store, llm)
    print(f"Ready. Backend: {llm.model}\n")

    def ask(question: str) -> dict:
        if force_basic:
            return pipeline.run_basic_only(question)
        return pipeline.run(question)

    if batch_file is not None:
        ts = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")
        report_path = OUTPUT_DIR / f"ask_batch_{'basic_' if force_basic else ''}{ts}.txt"
        header = (
            f"ask.py batch run — {ts}\n"
            f"mode: {'forced basic_rag' if force_basic else 'routed/advanced'}\n"
            f"source file: {batch_file}\n"
            + "=" * 70
        )
        _write(report_path, header)
        print(f"Writing results to: {report_path}\n")
        for raw_line in batch_file.read_text(encoding="utf-8").splitlines():
            line = raw_line.strip()
            if not line:
                continue
            if line.startswith("#"):
                # Section header/comment from the question file — carried
                # into the report so it stays readable, not sent as a query.
                _write(report_path, "\n" + line, append=True)
                print(line)
                continue
            print(f"Running: {line}")
            result = ask(line)
            block = _format_result(line, result)
            _write(report_path, block, append=True)
            print(f"  route={result['route']} techniques={result['techniques']}")
        print(f"\nDone. Full report saved to: {report_path}")
        return

    if args:
        question = " ".join(args)
        result = ask(question)
        block = _format_result(question, result)
        print(block)
        out_path = OUTPUT_DIR / "ask_last_result.txt"
        _write(out_path, block)
        print(f"\n(also saved to {out_path})")
        return

    print("Type a question (or 'quit' to exit). Conversation context carries")
    print("over between questions, same as the routed path's history.")
    out_path = OUTPUT_DIR / "ask_last_result.txt"
    print(f"Every answer below is also appended to {out_path}\n")
    _write(out_path, f"ask.py interactive session — {_dt.datetime.now():%Y-%m-%d %H:%M:%S}\n" + "=" * 70)
    while True:
        try:
            q = input("> ").strip()
        except (EOFError, KeyboardInterrupt):
            break
        if not q or q.lower() in {"quit", "exit"}:
            break
        result = ask(q)
        block = _format_result(q, result)
        print(block)
        _write(out_path, block, append=True)


if __name__ == "__main__":
    main()
