"""Quick offline tests for the improved router (heuristic only — no LLM/API needed)."""

from __future__ import annotations

import importlib.util
import sys
import types
from pathlib import Path

# Load router without pulling sklearn / torch / etc.
ROOT = Path(__file__).resolve().parent
# Prefer the updated package if present
CANDIDATES = [
    ROOT / "advanced_rag" / "router.py",
    ROOT / "Advancws_Rag_fixed" / "advanced_rag" / "router.py",
    Path("/tmp/rag_rebuild/Advancws_Rag_fixed/advanced_rag/router.py"),
    ROOT / "router.py",
]
router_path = next((p for p in CANDIDATES if p.exists()), None)
if not router_path:
    raise SystemExit("router.py not found. Put this script next to the project or update CANDIDATES.")

sys.modules["advanced_rag"] = types.ModuleType("advanced_rag")
sys.modules["advanced_rag.cost"] = types.ModuleType("advanced_rag.cost")
sys.modules["advanced_rag.llm"] = types.ModuleType("advanced_rag.llm")
sys.modules["advanced_rag.cost"].CostTracker = type("CostTracker", (), {})
sys.modules["advanced_rag.llm"].LLMClient = type("LLMClient", (), {})

spec = importlib.util.spec_from_file_location("router", router_path)
router = importlib.util.module_from_spec(spec)
spec.loader.exec_module(router)

# ---------------------------------------------------------------------------
# Test cases the TA is likely to invent (not in the official 10)
# ---------------------------------------------------------------------------
CASES = [
    # ---- SIMPLE ----
    ("S1", "What is RAG?", "simple", []),
    ("S2", "What is machine learning?", "simple", []),
    ("S3", "Hello, who are you?", "simple", []),
    ("S4", "Which approach should be used for a simple question versus a complex multi-part question?", "simple", []),
    ("S5", "When should I use simple vs advanced RAG?", "simple", []),

    # ---- BASIC_RAG (document-grounded, no special technique) ----
    ("B1", "How do I request a new access card for the branch?", "basic_rag", []),
    ("B2", "What are the steps for the annual stationery inventory?", "basic_rag", []),
    ("B3", "How does the Central Alarm unit handle fire signals?", "basic_rag", []),
    ("B4", "What procedures exist for extracting CCTV recordings?", "basic_rag", []),
    ("B5", "Explain the fixed-asset donation approval process.", "basic_rag", []),
    ("B6", "What does the mail unit do when a courier delivers damaged packages?", "basic_rag", []),

    # ---- REWRITE (ambiguous / short follow-up) ----
    ("R1", "Why is it bad?", "advanced_rag", ["rewrite"]),
    ("R2", "Why did that fail?", "advanced_rag", ["rewrite"]),
    ("R3", "What about it?", "advanced_rag", ["rewrite"]),

    # ---- MULTI_QUERY ----
    ("M1", "What are the main operational challenges and failure modes across alarm, warehouse and mail units?", "advanced_rag", ["multi_query"]),
    ("M2", "List risks and failure modes in Central Alarm and Central Mail.", "advanced_rag", ["multi_query"]),

    # ---- DECOMPOSITION ----
    ("D1", "Compare the Central Alarm procedures and the mail unit, list advantages and disadvantages, and say when to use each.", "advanced_rag", ["decomposition"]),
    ("D2", "Compare warehouse inventory vs fixed-asset inventory and list pros and cons.", "advanced_rag", ["decomposition"]),

    # ---- HYDE ----
    ("H1", "How do the manuals reduce mistakes, false handling, or unsupported actions during day-to-day operations?", "advanced_rag", ["hyde"]),
    ("H2", "How do the manuals help prevent errors in daily operations?", "advanced_rag", ["hyde"]),

    # ---- SELF_QUERY ----
    ("SQ1", "Find documents about warehouse or alarm procedures published after 2024.", "advanced_rag", ["self_query"]),
    ("SQ2", "Show me mail procedures from 2025 onwards.", "advanced_rag", ["self_query"]),
    ("SQ3", "Which manuals were issued after 2023?", "advanced_rag", ["self_query"]),

    # ---- CRAG ----
    ("C1", "If a pouch or registered item goes missing after it was logged, what should we do?", "advanced_rag", ["crag"]),
    ("C2", "What happens when a registered parcel disappears?", "advanced_rag", ["crag"]),
    ("C3", "A file was lost after logging — recovery steps?", "advanced_rag", ["crag"]),

    # ---- EDGE / MIXED ----
    ("E1", "Tell me the advantages of the alarm unit", "basic_rag", []),
    ("E2", "What is 2 + 2?", "simple", []),
    ("E3", "Summarize the reconciliation process in the warehouse manual", "basic_rag", []),
]


def main() -> None:
    print(f"Using router: {router_path}\n")
    passed = 0
    failed = 0
    for tid, question, exp_route, exp_techs in CASES:
        d = router.heuristic_route(question)
        got_route = d["route"]
        got_techs = d.get("techniques") or []
        # Core techniques must match; extra optional techs (rerank/compression) are ok if present
        core_ok = all(t in got_techs for t in exp_techs)
        route_ok = got_route == exp_route
        # For advanced we require at least the expected core techniques
        if exp_route == "advanced_rag":
            ok = route_ok and core_ok
        else:
            ok = route_ok and got_techs == []

        status = "PASS" if ok else "FAIL"
        if ok:
            passed += 1
        else:
            failed += 1
        print(f"[{status}] {tid}")
        print(f"  Q: {question[:70]}")
        print(f"  expected: {exp_route} | {exp_techs}")
        print(f"  got:      {got_route} | {got_techs}")
        if not ok:
            print(f"  reason:   {d.get('reason', '')[:100]}")
        print()

    print("=" * 50)
    print(f"Result: {passed} passed, {failed} failed  (total {len(CASES)})")
    if failed:
        sys.exit(1)


if __name__ == "__main__":
    main()
