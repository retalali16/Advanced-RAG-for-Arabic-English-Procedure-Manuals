# Required Results Table (routed / Advanced RAG path)

| ID | Route | Techniques Used | Context Rel. | Faithfulness | Answer Rel. | Correctness | Total Cost | Latency | Judge |
|---|---|---|---|---|---|---|---|---|---|
| Q1 | simple | - | N/A | 0.86 | 0.37 | 0.27 | 0.000104 | 0.64s | heuristic |
| Q2 | basic_rag | - | 0.25 | 0.21 | 0.47 | 0.22 | 0.000227 | 2.10s | heuristic |
| Q3 | advanced_rag | rewrite | 0.25 | 0.13 | 0.20 | 0.30 | 0.000415 | 3.17s | heuristic |
| Q4 | advanced_rag | multi_query | 0.25 | 0.10 | 0.58 | 0.24 | 0.000458 | 8.18s | heuristic |
| Q5 | advanced_rag | multi_query, decomposition | 0.25 | 0.17 | 0.63 | 0.55 | 0.000557 | 40.56s | heuristic |
| Q6 | advanced_rag | multi_query, hyde | 0.25 | 0.15 | 0.40 | 0.34 | 0.000646 | 32.44s | heuristic |
| Q7 | advanced_rag | multi_query, self_query | 0.25 | 0.00 | 0.20 | 0.00 | 0.000394 | 60.14s | heuristic |
| Q8 | basic_rag | - | 0.25 | 0.16 | 0.55 | 0.56 | 0.000291 | 1.89s | heuristic |
| Q9 | simple | - | N/A | 0.93 | 0.57 | 0.46 | 0.000101 | 0.89s | heuristic |
| Q10 | advanced_rag | multi_query, crag | 0.25 | 0.18 | 0.69 | 0.30 | 0.000498 | 12.58s | heuristic |

# Basic RAG comparison

| ID | Route | Techniques Used | Context Rel. | Faithfulness | Answer Rel. | Correctness | Total Cost | Latency | Judge |
|---|---|---|---|---|---|---|---|---|---|
| Q1 | basic_rag | - | 0.25 | 0.00 | 0.70 | 0.08 | 0.000147 | 13.68s | heuristic |
| Q2 | basic_rag | - | 0.25 | 0.11 | 0.73 | 0.55 | 0.000192 | 14.87s | heuristic |
| Q3 | basic_rag | - | 0.25 | 0.04 | 0.25 | 0.16 | 0.000199 | 14.67s | heuristic |
| Q4 | basic_rag | - | 0.25 | 0.09 | 0.59 | 0.43 | 0.000285 | 15.55s | heuristic |
| Q5 | basic_rag | - | 0.25 | 0.12 | 0.40 | 0.28 | 0.000305 | 15.45s | heuristic |
| Q6 | basic_rag | - | 0.25 | 0.22 | 0.44 | 0.29 | 0.000326 | 15.76s | heuristic |
| Q7 | basic_rag | - | 0.25 | 0.00 | 0.20 | 0.00 | 0.000169 | 39.83s | heuristic |
| Q8 | basic_rag | - | 0.25 | 0.10 | 0.55 | 0.70 | 0.000292 | 2.15s | heuristic |
| Q9 | basic_rag | - | 0.25 | 0.01 | 0.20 | 0.00 | 0.000161 | 1.12s | heuristic |
| Q10 | basic_rag | - | 0.25 | 0.13 | 0.82 | 0.26 | 0.000205 | 2.47s | heuristic |
