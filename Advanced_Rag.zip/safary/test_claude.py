import os
from dotenv import load_dotenv
from anthropic import Anthropic

load_dotenv()

client = Anthropic(
    api_key=os.getenv("ANTHROPIC_AUTH_TOKEN"),
    base_url=os.getenv("ANTHROPIC_BASE_URL"),
)

response = client.messages.create(
    model=os.getenv("ANTHROPIC_MODEL", "claude-opus-4-8"),
    max_tokens=100,
    messages=[
        {
            "role": "user",
            "content": "Reply with exactly: CLAUDE TEST OK"
        }
    ],
)

print("Model:", response.model)
print("Input tokens:", response.usage.input_tokens)
print("Output tokens:", response.usage.output_tokens)
print("Answer:", response.content[0].text)