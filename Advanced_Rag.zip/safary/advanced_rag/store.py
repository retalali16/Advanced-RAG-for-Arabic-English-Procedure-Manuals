"""Hybrid vector store: BM25 sparse retrieval always, optional dense embeddings.

BM25 replaced the previous TF-IDF + cosine-similarity sparse signal. TF-IDF
cosine similarity treats every corpus as a bag of unweighted term-frequency
vectors, which over/under-rewards document length and doesn't model term
saturation — on short, repetitive procedure-manual chunks (this corpus) that
made near-duplicate boilerplate paragraphs score artificially high. BM25
(Okapi) adds document-length normalization and diminishing returns for
repeated terms, which is the standard, much stronger sparse baseline used in
virtually every modern hybrid-RAG paper/setup (e.g. BM25 + dense fusion).
"""

from __future__ import annotations

import json
import pickle
import re
from dataclasses import dataclass
from pathlib import Path

import numpy as np
from rank_bm25 import BM25Okapi

from advanced_rag.config import INDEX_DIR
from advanced_rag.ingest import Chunk, ingest
from advanced_rag.llm import LLMClient

_TOKEN_RE = re.compile(r"[A-Za-z\u0600-\u06FF]{2,}")

# Arabic diacritics + tatweel
_DIACRITICS = re.compile(r"[\u0617-\u061A\u064B-\u0652\u0670\u0640]")

# Common Arabic prefixes / suffixes for light stemming (order matters: longer first)
_PREFIXES = (
    "وبال", "فبال", "كبال", "وال", "بال", "كال", "فال", "لل",
    "ال", "و", "ف", "ب", "ك", "ل",
)
_SUFFIXES = (
    "ات", "ية", "ين", "ون", "تين", "تان", "هما", "هم", "هن",
    "كم", "كن", "تم", "تن", "ها", "نا", "ة", "ه", "ي", "ك", "ت", "ا", "ن",
)

# Domain synonym groups — both query and corpus sides get expanded so
# "المخازن" matches "المستودعات", "إتلاف" matches "الاتلاف", etc.
_SYNONYM_GROUPS: list[tuple[str, ...]] = [
    ("مخزن", "مخازن", "مستودع", "مستودعات", "warehouse", "wearhouse"),
    ("اتلاف", "إتلاف", "اتلافها", "بالاتلاف", "بالإتلاف", "بإتلاف", "destruction", "dispose"),
    ("موجود", "موجودات", "اصول", "أصول", "assets"),
    ("لوج", "logs", "لقطات", "سجلات", "log"),
    ("bpm", "بي بي ام"),
    ("بريد", "مراسلات", "ملفات"),
    ("انذار", "إنذار", "امن", "أمن", "امنية", "أمنية"),
]


def _normalize_ar(tok: str) -> str:
    """Strip diacritics and unify Alef / Ya / Hamza variants."""
    tok = _DIACRITICS.sub("", tok)
    tok = (
        tok.replace("أ", "ا")
        .replace("إ", "ا")
        .replace("آ", "ا")
        .replace("ى", "ي")
        .replace("ؤ", "و")
        .replace("ئ", "ي")
        .replace("ة", "ه")  # taa marbuta → haa for matching
    )
    return tok


def _light_stem(tok: str) -> str:
    """Very light Arabic stemmer: strip one common prefix then one suffix."""
    tok = _normalize_ar(tok)
    orig = tok
    for p in _PREFIXES:
        if tok.startswith(p) and len(tok) - len(p) >= 2:
            tok = tok[len(p) :]
            break
    for s in _SUFFIXES:
        if tok.endswith(s) and len(tok) - len(s) >= 2:
            tok = tok[: -len(s)]
            break
    return tok if tok else orig


def _expand_synonyms(tokens: list[str]) -> list[str]:
    """Append canonical forms from synonym groups so BM25 sees both sides."""
    out = list(tokens)
    seen = set(tokens)
    for t in tokens:
        for group in _SYNONYM_GROUPS:
            if t in group or any(t.startswith(g) or g.startswith(t) for g in group if len(g) >= 3):
                for g in group:
                    if g not in seen:
                        out.append(g)
                        seen.add(g)
                break
    return out


def tokenize(text: str) -> list[str]:
    """Arabic-aware tokenizer shared by index build + query time.

    Improvements over the previous bare regex:
    - Remove Arabic diacritics / tatweel
    - Unify Alef/Ya/Hamza variants
    - Light prefix/suffix stemming so إتلاف / الاتلاف / بإتلاف share a stem
    - Domain synonym expansion (مخازن ↔ مستودعات, إتلاف variants, …)
    This fixes the page-6 vs page-26 ranking failure on the إتلاف/مخازن query
    and improves lexical hit rate for pure-Arabic procedure questions.
    """
    raw = _TOKEN_RE.findall((text or "").lower())
    stemmed = [_light_stem(t) for t in raw]
    # Keep both original normalized form and stem for better recall
    mixed: list[str] = []
    for orig, stem in zip(raw, stemmed):
        n = _normalize_ar(orig)
        if n:
            mixed.append(n)
        if stem and stem != n:
            mixed.append(stem)
    return _expand_synonyms(mixed)


def _bm25_scores(bm25: BM25Okapi, query: str) -> np.ndarray:
    scores = np.asarray(bm25.get_scores(tokenize(query)), dtype=np.float64)
    # Min-max normalize into [0, 1] so BM25 scores are on a comparable scale
    # to cosine-similarity dense scores when fused (dense_scores are already
    # ~[0, 1] since embeddings are L2-normalized before the dot product).
    # Without this, raw BM25 scores (unbounded, often >> 1) would dominate
    # or be dwarfed by dense scores depending on corpus size/term rarity.
    lo, hi = scores.min(), scores.max()
    if hi - lo < 1e-9:
        return np.zeros_like(scores)
    return (scores - lo) / (hi - lo)


@dataclass
class Hit:
    chunk: Chunk
    score: float
    rank: int
    method: str


class VectorStore:
    def __init__(self, chunks: list[Chunk], bm25: BM25Okapi, embeddings: np.ndarray | None):
        self.chunks = chunks
        self.bm25 = bm25
        self.embeddings = embeddings
        self.by_id = {c.chunk_id: c for c in chunks}

    @classmethod
    def build(cls, llm: LLMClient | None = None) -> "VectorStore":
        chunks_path = INDEX_DIR / "chunks.json"
        if chunks_path.exists():
            raw = json.loads(chunks_path.read_text(encoding="utf-8"))
            chunks = [Chunk(**row) for row in raw]
        else:
            chunks = ingest()
        texts = [c.text for c in chunks]
        bm25 = BM25Okapi([tokenize(t) for t in texts])
        embeddings = None
        if llm and llm.use_dense_embeddings:
            import time

            vectors = []
            # BGE-M3 is a local model, so batches can be larger and
            # back-to-back; the Gemini path keeps a small batch + pause to stay
            # under free-tier RPM limits (embed_texts also retries on 429).
            batch = 32 if llm.use_bge_embeddings else 16
            for i in range(0, len(texts), batch):
                part = llm.embed_texts(texts[i : i + batch], tracker=None, step="index_embed")
                if part:
                    vectors.extend(part)
                if llm.use_gemini_embeddings and i + batch < len(texts):
                    time.sleep(2)
            if vectors and len(vectors) == len(texts):
                embeddings = np.array(vectors, dtype=np.float32)
            elif vectors:
                print(
                    f"[store] Only {len(vectors)}/{len(texts)} chunks got Gemini embeddings "
                    "(quota likely ran out partway through); falling back to TF-IDF-only retrieval "
                    "rather than mixing partial embeddings."
                )
        INDEX_DIR.mkdir(parents=True, exist_ok=True)
        with (INDEX_DIR / "bm25.pkl").open("wb") as f:
            pickle.dump({"bm25": bm25}, f)
        if embeddings is not None:
            np.save(INDEX_DIR / "embeddings.npy", embeddings)
        return cls(chunks, bm25, embeddings)

    @classmethod
    def load(cls, llm: LLMClient | None = None) -> "VectorStore":
        chunks_path = INDEX_DIR / "chunks.json"
        bm25_path = INDEX_DIR / "bm25.pkl"
        legacy_tfidf_path = INDEX_DIR / "tfidf.pkl"
        if legacy_tfidf_path.exists() and not bm25_path.exists():
            # Old TF-IDF index from before the BM25 switch — can't be reused
            # (different structure/scores), so force a rebuild rather than
            # silently loading it or crashing on unpickle.
            print("[store] Found legacy tfidf.pkl index; rebuilding as BM25 (delete data/index/* to silence this).")
            return cls.build(llm)
        if not chunks_path.exists() or not bm25_path.exists():
            return cls.build(llm)
        raw = json.loads(chunks_path.read_text(encoding="utf-8"))
        chunks = [Chunk(**row) for row in raw]
        with bm25_path.open("rb") as f:
            blob = pickle.load(f)
        embeddings = None
        npy = INDEX_DIR / "embeddings.npy"
        if npy.exists():
            embeddings = np.load(npy)
        return cls(chunks, blob["bm25"], embeddings)

    def search(
        self,
        query: str,
        k: int = 6,
        year_gte: int | None = None,
        year_lte: int | None = None,
        source_contains: str | None = None,
        unit_contains: str | None = None,
        dense_query_vec: np.ndarray | None = None,
        use_hybrid: bool = True,
    ) -> list[Hit]:
        """Vector search over the corpus.

        use_hybrid=False -> PURE embedding vector search (Question -> Embedding
        -> Vector Search -> Top-K), exactly the Basic RAG pipeline from the
        requirements. BM25 is not consulted at all in this mode; if no dense
        embeddings are available it degrades to BM25 only as a last resort
        (so the system still returns something rather than nothing).

        use_hybrid=True -> Advanced RAG's optional retrieval enhancement:
        fuses dense (embedding) and sparse (BM25) scores. This is additive
        on top of the Basic RAG pipeline, never a replacement for it, and is
        only exercised on the routed/advanced_rag path.
        """
        mask = np.ones(len(self.chunks), dtype=bool)
        for i, c in enumerate(self.chunks):
            if year_gte is not None and (c.year is None or c.year < year_gte):
                mask[i] = False
            if year_lte is not None and (c.year is None or c.year > year_lte):
                mask[i] = False
            if source_contains and source_contains.lower() not in c.source.lower() and source_contains.lower() not in c.unit.lower():
                mask[i] = False
            if unit_contains and unit_contains.lower() not in c.unit.lower():
                mask[i] = False

        dense_scores = None
        if self.embeddings is not None and dense_query_vec is not None:
            q = dense_query_vec / (np.linalg.norm(dense_query_vec) + 1e-9)
            mat = self.embeddings / (np.linalg.norm(self.embeddings, axis=1, keepdims=True) + 1e-9)
            dense_scores = mat @ q

        if dense_scores is not None and not use_hybrid:
            # Basic RAG: pure embedding vector search, no BM25 involved.
            scores = dense_scores
        elif dense_scores is not None and use_hybrid:
            # Dense + BM25 fusion. Sparse weight raised from 0.35 → 0.45 because
            # this corpus is Arabic OCR with frequent synonym/OCR mismatches
            # (مخازن vs مستودعات, Logs rendered as "85هاللأنظمة"). Pure dense
            # systematically misses the correct page; BM25 with Arabic-aware
            # tokenize recovers it. Dense still leads so semantic near-misses
            # stay competitive.
            sparse_scores = _bm25_scores(self.bm25, query)
            scores = 0.55 * dense_scores + 0.45 * sparse_scores
        else:
            # No embeddings available at all (EMBEDDING_BACKEND=none or the
            # query embed call failed) -> BM25 is the only fallback signal.
            scores = _bm25_scores(self.bm25, query)

        scores = np.where(mask, scores, -1.0)

        # Targeted lexical boost for high-value procedure phrases that OCR +
        # dense often under-rank (BPM multi-doc, approver tables, escalation).
        q_low = (query or "").lower()
        boost_rules: list[tuple[tuple[str, ...], tuple[str, ...], float]] = [
            # (query markers, chunk markers, boost)
            (
                ("bpm", "بي بي", "اتمتة", "أتمتة"),
                ("bpm", "اتمتة", "اتمتة", "تبادل البريد", "مناقلات"),
                0.25,
            ),
            (
                ("جناح", "صلاحية الموافقة على دخول"),
                ("جناح الإدارة", "مدير مساعد", "نائب رئيس", "مدير - الأمن"),
                0.20,
            ),
            (
                ("فقدت", "ضياع", "مغلف"),
                ("مدير - المطبعة", "مدير - مطبعة", "قيمة الخصم", "شركة البريد"),
                0.15,
            ),
            (
                ("مدراء الأنظمة", "لقطات الـ logs الخاصة بمدراء", "logs الخاصة بمدراء"),
                ("بشكل سنوي", "عينات عشوائية", "مدراء"),
                0.15,
            ),
        ]
        for q_marks, c_marks, boost in boost_rules:
            if not any(m in q_low or m in (query or "") for m in q_marks):
                continue
            for i, c in enumerate(self.chunks):
                if not mask[i] or scores[i] < 0:
                    continue
                ct = (c.text or "").lower()
                if any(m.lower() in ct or m in (c.text or "") for m in c_marks):
                    scores[i] = float(scores[i]) + boost

        order = np.argsort(scores)[::-1]
        hits = []
        for rank, idx in enumerate(order[:k], start=1):
            if scores[idx] < 0:
                continue
            hits.append(Hit(chunk=self.chunks[int(idx)], score=float(scores[idx]), rank=rank, method="dense" if not use_hybrid and dense_scores is not None else "hybrid"))
        return hits