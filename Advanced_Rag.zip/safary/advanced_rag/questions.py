"""Evaluation set mapped onto all three procedure manuals (Central Alarm,
Assets and Warehouse Operations, Central Mail and Files).

Every "reference" below was checked against real OCR text extracted with
the Arabic Tesseract language pack installed (tesseract-ocr-ara). Without
that pack, "lang=ara" silently reads Arabic glyphs as Latin lookalikes and
produces garbage ("Aull Lig" instead of "بنك الإسكان", etc.) — see
FIXES_APPLIED.md. The Central Alarm manual is almost entirely Arabic, so it
was the most exposed to this bug; re-OCR'ing it with the Arabic pack
installed is what made grounding Q2/Q3/Q4/Q8 below possible at all.

Each entry's "citations" list records the manual and the printed page
footer (e.g. "6/20") the reference was verified against, so the ground
truth itself is auditable. Distribution across the corpus:
  - Central Alarm Tasks and Procedures Manual: Q2, Q3, Q4, Q8
  - Assets and Warehouse Operations manual: Q6
  - Central Mail and Files manual: Q5 (paired with Central Alarm), Q10
  - Not corpus-grounded (general/routing knowledge): Q1, Q9
Each question keeps the exact same "challenge" technique its ID is meant to
test (rewrite/multi_query/decomposition/hyde/self_query/rerank/crag).
"""

from __future__ import annotations

QUESTIONS = [
    {
        "id": "Q1",
        "question": "What is Retrieval-Augmented Generation (RAG)?",
        "focus": "Simple/general knowledge; should usually route to simple/direct and not force retrieval.",
        "challenge": "simple",
        "reference": (
            "RAG retrieves relevant documents and conditions a language model on that evidence "
            "instead of relying only on parametric memory."
        ),
        "citations": ["general knowledge; not corpus-grounded"],
    },
    {
        "id": "Q2",
        "question": (
            "What rules and approval steps does the Central Alarm manual set for issuing, "
            "replacing, or canceling access-control cards and fingerprint credentials?"
        ),
        "focus": "Document-grounded factual question.",
        "challenge": "basic_doc",
        "reference": (
            "The Central Alarm manual sets a card/fingerprint replacement-fine policy: a lost access "
            "card is deactivated and the employee is fined 10 JOD (credited to a miscellaneous-revenue "
            "account); a damaged card is replaced free of charge if the damage is due to a technical "
            "fault, or if it is due to normal wear after the card has been held more than two years, "
            "otherwise the same 10 JOD fine applies. Fine waivers require approval from the Deputy CEO "
            "- Administrative and Engineering Affairs. Issuing a new card/fingerprint goes through a "
            "defined chain: an Operations Room officer receives the request via the unit's official "
            "email (esec@hbtf.com.jo) and verifies the employee's branch, name, employee number, job "
            "title, hire date, and workplace; a security-systems officer then verifies the approving "
            "authority per the general rules table before the Assistant Manager - Central Alarm signs "
            "off (escalating to the Manager - Security and Central Alarm for higher-authority requests); "
            "a weekly report of all issued/canceled/modified cards and fingerprints is sent up the same "
            "chain."
        ),
        "citations": [
            "Central Alarm Tasks and Procedures Manual, pp.5-6 (card/PIN rules and fine policy), "
            "pp.7-8 (card/fingerprint issuance procedure and approval chain)",
        ],
    },
    {
        "id": "Q3",
        "question": "Why is it bad?",
        "focus": "Ambiguous/conversational follow-up; rewrite using Q2 as prior context.",
        "challenge": "rewrite",
        "reference": (
            "Skipping the Central Alarm manual's verification and approval chain from Q2 is bad "
            "because those steps exist specifically to make sure only the right, currently-employed "
            "person holds an active card or fingerprint credential on the access-control system: "
            "without checking hire date, prior workplace, and that no duplicate/other-site credential "
            "exists, a former employee or an unauthorized duplicate could keep working access; without "
            "the fine and manager sign-off on replacements, lost/damaged cards would go unreported and "
            "unreconciled, and without the weekly report to the Security and Central Alarm manager, "
            "nobody reviews the accumulated set of active credentials across all branches."
        ),
        "citations": [
            "Central Alarm Tasks and Procedures Manual, pp.5-8 (verification steps, fine/waiver policy, weekly reporting)"
        ],
    },
    {
        "id": "Q4",
        "question": (
            "What are the operational challenges and failure modes in the Central Alarm unit's "
            "CCTV monitoring, footage-retention compliance, and PIN/passcode management duties?"
        ),
        "focus": "Multi-query / multiple search perspectives across sub-topics in one manual.",
        "challenge": "multi_query",
        "reference": (
            "CCTV monitoring: the unit must continuously confirm all branch, ATM, and building cameras "
            "are working, checking for video-loss, recorder stoppage, unreachable devices, or poor image "
            "quality, and reviewing footage at least every 3 months; if an ATM's cameras go down and the "
            "issue can't be fixed quickly, the area/cash-unit manager must be notified to decide whether "
            "to suspend cash withdrawals or take the ATM out of service. Footage-retention compliance: "
            "retention periods must match Central Bank and Ministry of Interior instructions, verified "
            "monthly, and any recording-loss incident must be logged (cause of loss, duration, the "
            "vendor's technical report, and the actions taken). PIN/passcode management: site codes and "
            "phone numbers used by branch-opening/closing personnel must be reconciled at least every six "
            "months, and each employee's PIN must be changed at least every six months."
        ),
        "citations": [
            "Central Alarm Tasks and Procedures Manual, p.7 (CCTV monitoring duties, ATM camera failure escalation, "
            "monthly retention compliance, recording-loss logging), p.6 (six-monthly PIN/passcode reconciliation)"
        ],
    },
    {
        "id": "Q5",
        "question": (
            "Compare the Central Alarm procedures and the Central Mail and Files Unit procedures, "
            "explain their advantages and disadvantages, and state when each unit's process should be used."
        ),
        "focus": "Complex multi-part question; decomposition.",
        "challenge": "decomposition",
        "reference": (
            "Central Alarm is responsible for technical security services across all branches and "
            "buildings — access-control cards/fingerprints, CCTV monitoring, alarm signal verification, "
            "and escalation to the General Security Operations Center; its advantage is continuous, "
            "24/7 monitoring with a documented approval chain for every access change, its disadvantage "
            "is heavy dependence on third-party maintenance contracts and camera/recorder uptime it does "
            "not fully control. Central Mail and Files is the hub for incoming/outgoing correspondence "
            "and file retention/destruction between branches and departments; its advantage is a "
            "documented, traceable paper/electronic trail, its disadvantage is dependence on external "
            "courier companies, which creates liability disputes when mail is lost or damaged. Use "
            "Central Alarm's process for physical/access security, card and camera matters; use Central "
            "Mail and Files' process for correspondence handling, filing, and lost/damaged mail claims."
        ),
        "citations": [
            "Central Alarm Tasks and Procedures Manual, pp.4-8 (unit purpose and core procedures)",
            "Central Mail and Files manual, p.4 (unit purpose), p.29 (courier liability handling)",
        ],
    },
    {
        "id": "Q6",
        "question": (
            "How does the Assets and Warehouse Operations manual reduce mistakes, false handling, or "
            "unsupported actions in warehouse counts and asset reconciliation?"
        ),
        "focus": (
            "HyDE challenge: the question uses everyday risk-language ('reduce mistakes, false "
            "handling, unsupported actions') that does not literally appear in the manual, which "
            "instead uses administrative/procedural vocabulary ('reconciliation', 'corrective "
            "accounting entry', 'count committee'). A raw query embedding of the question is expected "
            "to under-match those procedure paragraphs on vocabulary alone; HyDE's hypothetical-document "
            "step is what's supposed to bridge that gap."
        ),
        "challenge": "hyde",
        "reference": (
            "The manual reduces error through a dedicated count committee and sign-off chain for "
            "physical inventories, and routine monthly/quarterly reconciliation cycles that raise "
            "corrective accounting entries whenever a system balance and a physical count disagree, "
            "with the reconciliation result and any recommended correcting entry routed to the "
            "first-responsible officer for review and approval before posting."
        ),
        "citations": [
            "Assets and Warehouse Operations manual, pp.8-9 (annual inventory / count committee), "
            "pp.12-15 (monthly/quarterly reconciliation and approval)",
        ],
    },
    {
        "id": "Q7",
        "question": "Find documents about alarm, warehouse, or mail procedures published after 2024.",
        "focus": "Self-query with year metadata filter, now spanning all three manuals.",
        "challenge": "self_query",
        "reference": (
            "All three manuals qualify: the Central Alarm manual, the Assets and Warehouse Operations "
            "manual, and the Central Mail and Files manual are each stamped with an issue date of "
            "08/2024 and a last-review date of 02/2026. A correct self-query filter of year >= 2025 "
            "(using the last-review date) should therefore return chunks from all three sources, not "
            "report that no documents match."
        ),
        "citations": [
            "Central Alarm Tasks and Procedures Manual, p.1 (version footer: issue 08/2024, last review 02/2026)",
            "data/index/inventory.json meta_year for all three PDFs",
        ],
    },
    {
        "id": "Q8",
        "question": (
            "What procedure does the Central Alarm manual describe for issuing and activating access "
            "cards and fingerprints on the access-control systems?"
        ),
        "focus": (
            "Reranking challenge: first-pass hybrid retrieval over this manual returns several "
            "generic/header chunks (the table-of-contents entry naming the card/fingerprint "
            "issue-stop-cancel-change procedure, and the section-title line that repeats it) mixed in "
            "with the actual step-by-step issuance procedure, because headers share surface vocabulary "
            "with the question. The challenge this question is designed to exercise is whether "
            "reranking (keyword_rerank / llm_rerank in retrieve.py) promotes the procedural chunk over "
            "the header chunks -- not the question wording itself."
        ),
        "challenge": "rerank",
        "reference": (
            "An Operations Room officer receives the card/fingerprint request via the unit's official "
            "email and verifies the employee's branch, full name, employee number, job title, hire "
            "date, workplace, prior work center (if any), that no card was already issued to them, and "
            "that they have a pre-defined profile on the access-control system; the request then goes "
            "to a security-systems officer, who checks the approving authority per the general rules and "
            "forwards it to the Assistant Manager - Central Alarm, who confirms all information and "
            "approvals are complete (verifying fee payment or a waiver approval for lost/damaged-card "
            "replacements) before approving or escalating to the Manager - Security and Central Alarm "
            "for higher-authority cases; once approved, the card is issued and the access-control system "
            "activated, or for fingerprints the approval is sent to the central alarm station to activate "
            "the fingerprint with the requested privileges."
        ),
        "citations": [
            "Central Alarm Tasks and Procedures Manual, p.2 (table of contents, item 1: card/fingerprint "
            "issue-stop-cancel-change procedure), pp.7-8 (actual issuance procedure steps)"
        ],
    },
    {
        "id": "Q9",
        "question": "Which approach should be used for a simple question versus a complex multi-part question?",
        "focus": "Routing decision question; may be answered without manuals.",
        "challenge": "routing",
        "reference": (
            "Simple questions can use a direct answer or basic RAG. Complex multi-part questions should be "
            "routed to advanced RAG with only the needed techniques such as decomposition and multi-query."
        ),
        "citations": ["routing-policy question; not corpus-grounded"],
    },
    {
        "id": "Q10",
        "question": "If a pouch, registered item, or file goes missing after it was logged, what recovery and notification steps do the mail and files procedures require?",
        "focus": "CRAG/retrieval-correction; colloquial missing-item wording may miss first-pass retrieval.",
        "challenge": "crag",
        "reference": (
            "The Central Mail and Files procedure for loss/damage/shortage of sent or received mail is: the "
            "work-center report (email or memo) is received and forwarded to the admin employee; the "
            "relevant courier company is contacted for its response; the affected work centers are asked to "
            "state the extent and value of the damage; the responses are reviewed and the bank tries to "
            "settle with the courier by emailing them the assessed damage value; if the courier agrees to a "
            "deduction/fine, the Payroll and Expenses unit deducts the amount and credits the concerned work "
            "center's account; if the courier disputes it and no agreement is reached, the contract terms "
            "are applied and the case is escalated to the Printing and Warehouses manager, who decides, and "
            "the decision is executed and filed."
        ),
        "citations": ["Central Mail and Files manual, pp.28-29 (item 7: handling loss/damage/shortage of mail)"],
    },
]
