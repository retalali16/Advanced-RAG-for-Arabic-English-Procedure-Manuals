"""End-to-end routed RAG pipeline."""

from __future__ import annotations

import re
from typing import Any

from advanced_rag.bilingual import expand_query
from advanced_rag.config import AUTO_LOW_CONFIDENCE_RETRY, CRAG_INCORRECT_THRESHOLD, MAX_CONTEXT_CHARS, TOP_K
from advanced_rag.cost import CostTracker, Timer
from advanced_rag.generate import generate_answer
from advanced_rag.llm import LLMClient
from advanced_rag.retrieve import compress_hits, context_relevance_score, crag_evaluate, format_hits, llm_rerank, rrf_merge
from advanced_rag.router import route_question
from advanced_rag.store import Hit, VectorStore
from advanced_rag.transforms import decompose, hyde_document, multi_query, rewrite_query, self_query


SKIPPABLE = [
    "router",
    "rewrite",
    "multi_query",
    "decomposition",
    "hyde",
    "self_query",
    "rerank",
    "compression",
    "crag",
    "final_generation",
]


class RAGPipeline:
    def __init__(self, store: VectorStore, llm: LLMClient):
        self.store = store
        self.llm = llm
        self.history: list[str] = []

    def reset_history(self) -> None:
        self.history = []

    def conversation(self) -> str:
        return "\n".join(self.history[-4:])

    def _search(self, query: str, k: int = TOP_K, filters: dict | None = None, tracker: CostTracker | None = None, use_hybrid: bool = True) -> list[Hit]:
        filters = filters or {}
        dense = None
        if self.llm.use_dense_embeddings:
            vecs = self.llm.embed_texts([query], tracker=tracker, step="query_embed", is_query=True)
            if vecs:
                import numpy as np

                dense = np.array(vecs[0], dtype="float32")
        return self.store.search(
            expand_query(query),
            k=k,
            year_gte=filters.get("year_gte"),
            year_lte=filters.get("year_lte"),
            source_contains=filters.get("source_contains"),
            unit_contains=filters.get("unit_contains"),
            dense_query_vec=dense,
            use_hybrid=use_hybrid,
        )

    def run(self, question: str, force_route: dict[str, Any] | None = None) -> dict[str, Any]:
        tracker = CostTracker()
        notes: dict[str, Any] = {}
        executed: list[str] = []
        with Timer() as wall:
            decision = force_route or route_question(question, self.llm, tracker, self.conversation())
            executed.append("router")
            route = decision["route"]
            techniques = list(decision.get("techniques") or [])
            search_query = question
            filters: dict[str, Any] = {}
            hits: list[Hit] = []
            context = ""
            tokens_before = 0
            tokens_after = 0

            if route == "simple":
                for step in SKIPPABLE:
                    if step not in {"router", "final_generation"}:
                        tracker.mark_skipped(step)
                answer = generate_answer(
                    question,
                    "",
                    self.llm,
                    tracker,
                    conversation=self.conversation(),
                    allow_parametric=True,
                )
            else:
                if "rewrite" in techniques:
                    search_query = rewrite_query(question, self.llm, tracker, self.conversation())
                    executed.append("rewrite")
                    notes["rewritten"] = search_query
                else:
                    tracker.mark_skipped("rewrite")

                if "self_query" in techniques:
                    sq = self_query(question, self.llm, tracker)
                    search_query = sq.get("semantic_query") or search_query
                    filters = sq.get("filters") or {}
                    executed.append("self_query")
                    notes["self_query"] = sq
                else:
                    tracker.mark_skipped("self_query")

                query_list = [search_query]
                if "multi_query" in techniques:
                    query_list = multi_query(search_query, self.llm, tracker)
                    executed.append("multi_query")
                    notes["multi_query"] = query_list
                else:
                    tracker.mark_skipped("multi_query")

                if "decomposition" in techniques:
                    subs = decompose(question, self.llm, tracker)
                    executed.append("decomposition")
                    notes["subquestions"] = subs
                    query_list = list(dict.fromkeys(query_list + subs))
                else:
                    tracker.mark_skipped("decomposition")

                if "hyde" in techniques:
                    hypo = hyde_document(search_query, self.llm, tracker)
                    executed.append("hyde")
                    notes["hyde"] = hypo[:500]
                    query_list = list(dict.fromkeys(query_list + [hypo]))
                else:
                    tracker.mark_skipped("hyde")

                # Hybrid (dense + BM25) is the default for BOTH basic_rag and
                # advanced_rag on this corpus. Pure-dense basic_rag fails on
                # Arabic OCR-garbled procedure manuals: synonym mismatches
                # (مخازن/مستودعات) and OCR corruptions (Logs → "85هاللأنظمة")
                # make the correct page invisible to embeddings alone.
                # BM25 with Arabic-aware tokenize recovers the right page;
                # hybrid keeps semantic ranking while fixing lexical misses.
                # Advanced path can still list "hybrid_retrieval" explicitly
                # in techniques for reporting; the retrieval itself always
                # fuses both signals unless EMBEDDING_BACKEND leaves us with
                # no dense vectors at all.
                use_hybrid = True
                hit_lists = [self._search(q, k=TOP_K, filters=filters, tracker=tracker, use_hybrid=use_hybrid) for q in query_list]
                hits = rrf_merge(hit_lists, k=TOP_K) if len(hit_lists) > 1 else hit_lists[0]
                notes["initial_hit_ids"] = [h.chunk.chunk_id for h in hits]

                if "crag" in techniques:
                    crag = crag_evaluate(search_query, hits, self.llm, tracker)
                    executed.append("crag")
                    notes["crag"] = crag
                    if crag.get("decision") in {"incorrect", "ambiguous"}:
                        rewritten = rewrite_query(search_query + " procedures responsibilities steps", self.llm, tracker, self.conversation())
                        notes["crag_rewrite"] = rewritten
                        broader = self._search(rewritten, k=TOP_K + 4, filters={}, tracker=tracker, use_hybrid=use_hybrid)
                        hits = rrf_merge([hits, broader], k=TOP_K)
                        notes["crag_retry_ids"] = [h.chunk.chunk_id for h in hits]
                else:
                    tracker.mark_skipped("crag")
                    # FIX (found via real testing — OCR-garbled source pages
                    # cause wrong-chunk retrieval on ordinary factual
                    # questions the router never flagged as "likely weak
                    # retrieval"): CRAG's own corrective retry used to only
                    # run when the router pre-guessed "crag" from the
                    # question's WORDING (colloquial/missing-item phrasing).
                    # That's a-priori and misses real, OCR-noise-driven weak
                    # retrieval on completely ordinary questions (a clean
                    # question against a badly-OCR'd manual page can score
                    # just as low as a colloquial one). This runs the exact
                    # same empirical confidence check CRAG itself uses
                    # (semantic+lexical blend, see retrieve.py) against the
                    # ACTUAL retrieved hits, for every non-crag route, and
                    # only pays for the extra rewrite+search call when
                    # confidence is genuinely low — not a blanket cost
                    # increase on every question. Toggle via
                    # AUTO_LOW_CONFIDENCE_RETRY in config.py if a quota-
                    # limited backend needs to opt out of the extra call.
                    if AUTO_LOW_CONFIDENCE_RETRY:
                        confidence = context_relevance_score(search_query, hits)
                        notes["auto_confidence_score"] = confidence
                        if confidence < CRAG_INCORRECT_THRESHOLD:
                            rewritten = rewrite_query(
                                search_query + " procedures responsibilities steps",
                                self.llm,
                                tracker,
                                self.conversation(),
                            )
                            notes["auto_retry_rewrite"] = rewritten
                            broader = self._search(rewritten, k=TOP_K + 4, filters={}, tracker=tracker, use_hybrid=use_hybrid)
                            hits = rrf_merge([hits, broader], k=TOP_K)
                            notes["auto_retry_ids"] = [h.chunk.chunk_id for h in hits]
                            executed.append("auto_low_confidence_retry")

                if "rerank" in techniques:
                    hits = llm_rerank(question, hits, self.llm, tracker)
                    executed.append("rerank")
                    notes["reranked_ids"] = [h.chunk.chunk_id for h in hits]
                else:
                    tracker.mark_skipped("rerank")

                if "compression" in techniques:
                    # Was `use_llm=self.llm.use_gemini` — always False with
                    # Ollama, so compress_hits() was doubly gated shut (see
                    # retrieve.py). Pass True; compress_hits now decides for
                    # itself via `llm.use_real_llm` whether a backend exists.
                    context, tokens_before, tokens_after = compress_hits(
                        question, hits, self.llm, tracker, use_llm=True
                    )
                    executed.append("compression")
                    notes["compression"] = {
                        "tokens_before": tokens_before,
                        "tokens_after": tokens_after,
                        "removed": tokens_before - tokens_after,
                    }
                else:
                    tracker.mark_skipped("compression")
                    context = format_hits(hits)
                    tokens_before = tokens_after = max(1, len(context) // 4)

                # FIX (quota safety for paid/rate-limited backends like
                # Groq): hard cap on total context characters sent in the
                # final-generation prompt, independent of TOP_K/CHUNK_SIZE/
                # COMPRESSION_SENTENCES math. multi_query/decomposition/hyde
                # can each add extra search queries feeding the SAME context
                # block, so TOP_K alone doesn't bound the final prompt size.
                # Truncates at a whole-chunk boundary (splits on the
                # "[chunk_...]" markers format_hits()/compress_hits() emit)
                # rather than mid-sentence, so a cut context block still
                # reads as complete excerpts instead of a garbled fragment.
                if len(context) > MAX_CONTEXT_CHARS:
                    pieces = re.split(r"(?=\[chunk_)", context)
                    kept: list[str] = []
                    total = 0
                    for piece in pieces:
                        if total + len(piece) > MAX_CONTEXT_CHARS and kept:
                            break
                        kept.append(piece)
                        total += len(piece)
                    context = "".join(kept).strip() or context[:MAX_CONTEXT_CHARS]
                    notes["context_truncated_to_chars"] = len(context)

                # Hints help small local models avoid common logic errors
                hints = []
                if "self_query" in techniques and filters.get("year_gte"):
                    hints.append(
                        f"Metadata filter year_gte={filters['year_gte']} was applied. "
                        "Any chunk with year >= that value satisfies the date constraint "
                        "(e.g. year 2026 satisfies 'published after 2024'). "
                        "List the matching manuals/units found; do NOT say no documents exist."
                    )
                if "rewrite" in techniques and len(question.split()) <= 6:
                    hints.append(
                        "This is a short follow-up. Use the conversation to identify the procedures "
                        "just discussed and explain risks of skipping them (discrepancies, corrective entries)."
                    )
                if "multi_query" in techniques or "decomposition" in techniques:
                    hints.append(
                        "You may state implied challenges/failure modes that the described controls exist to prevent."
                    )
                if "crag" in techniques:
                    notes.get("crag")  # keep notes intact
                    hints.append(
                        "Focus on loss/damage/shortage recovery and notification steps from the mail/files procedures."
                    )

                # Question-specific completeness hints (small models often drop
                # secondary table rows / the annual frequency line).
                q = question or ""
                if "جناح الإدارة" in q or "جناح الادارة" in q:
                    hints.append(
                        "من جدول الموافقات: اذكر كل أصحاب الصلاحية للدخول إلى جناح الإدارة "
                        "من جهة الشؤون الإدارية (مدير مساعد الإنذار المركزي، ونائب رئيس - "
                        "مدير الشؤون الإدارية والهندسية، ومدير الأمن والإنذار المركزي)، "
                        "وليس اسماً واحداً فقط."
                    )
                if ("مدراء الأنظمة" in q or "مدراء الانظمة" in q) and (
                    "log" in q.lower() or "logs" in q.lower() or "لوج" in q or "سجلات" in q or "لقطات" in q
                ):
                    hints.append(
                        "ابدأ بالدورية أولاً: تتم المراجعة بشكل سنوي كحد أدنى أو حسب الحاجة، "
                        "مع أخذ عينات عشوائية من الـ Logs. بعدها يمكن ذكر الحالات التي تستدعي المراجعة."
                    )
                if "BPM" in q.upper() or "bpm" in q.lower() or "بي بي" in q:
                    hints.append(
                        "غطِّ دور BPM في وحدة البريد (أتمتة/تتبع المراسلات) وفي وحدة الموجودات "
                        "(ترحيل مناقلات الموجودات الثابتة خلال يومين عمل) إن ورد ذلك في المقتطفات."
                    )

                answer = generate_answer(
                    question,
                    context,
                    self.llm,
                    tracker,
                    conversation=self.conversation(),
                    extra_hints="\n".join(hints),
                )

        self.history.append(f"Q: {question}")
        self.history.append(f"A: {answer[:400]}")
        return {
            "question": question,
            "route": route,
            "reason": decision.get("reason"),
            "techniques": techniques,
            "executed": executed,
            "retrieved_ids": [h.chunk.chunk_id for h in hits],
            "retrieved_sources": [
                {
                    "chunk_id": h.chunk.chunk_id,
                    "source": h.chunk.source,
                    "page": h.chunk.page,
                    "year": h.chunk.year,
                    "score": h.score,
                    "text": (h.chunk.text or ""),
                }
                for h in hits
            ],
            "context": context,
            "answer": answer,
            "notes": notes,
            "tokens_before_compression": tokens_before,
            "tokens_after_compression": tokens_after,
            "cost": {
                "input_tokens": tracker.total_input_tokens,
                "output_tokens": tracker.total_output_tokens,
                "total_cost_usd": round(tracker.total_cost, 8),
                "llm_latency_s": round(tracker.total_latency, 4),
                "wall_latency_s": round(wall.elapsed, 4),
                "breakdown": tracker.breakdown(),
            },
        }

    def run_basic_only(self, question: str) -> dict[str, Any]:
        return self.run(question, force_route={"route": "basic_rag", "reason": "forced baseline", "techniques": []})