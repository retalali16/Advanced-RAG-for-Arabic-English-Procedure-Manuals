"""English assignment questions → Arabic procedure-manual search terms."""

from __future__ import annotations

GLOSSARY: list[tuple[tuple[str, ...], str]] = [
    (
        ("warehouse", "wearhouse", "assets", "inventory", "stationery", "fixed assets"),
        "موجودات مستودعات جرد قرطاسية أمانات مخزون طلبيات الموجودات الثابتة",
    ),
    (
        ("donation", "gift request"),
        "اهداء طلبات اهداء الموجودات الثابتة",
    ),
    (
        ("reconciliation", "account matching", "matching"),
        "مطابقة المطابقات الشهرية الربعية قيود محاسبية تصحيحية فروقات",
    ),
    (
        ("porterage", "transport invoice", "transport invoices"),
        "فواتير النقل والعتالة متعهد النقل",
    ),
    (
        ("dormant stock", "obsolete stock"),
        "المخزون الراكد اللوازم والقرطاسية",
    ),
    (
        ("alarm", "access card", "fingerprint", "camera", "escalat"),
        "انذار مركزي بطاقات بصمات التحكم بالدخول المراقبة التلفزيونية صلاحيات",
    ),
    (
        ("cctv", "recording", "extract"),
        "استخراج تسجيلات مراقبة تلفزيونية",
    ),
    (
        ("fire", "theft"),
        "انذار الحريق والسرقة والاتصال الالي",
    ),
    (
        ("mail", "files", "pouch", "registered", "correspondence", "lending"),
        "بريد ملفات مراسلات الحفظ والاتلاف وحدة البريد المركزي",
    ),
    (
        ("missing", "lost", "recovery", "notification", "damage", "shortage"),
        "نقص تلف ضياع البريد شركة البريد الناقلة خصم تغريم",
    ),
    (("limitation", "control", "task", "procedure", "challenge", "failure"), "إجراءات قواعد أحكام مسؤوليات ضوابط"),
    (
        ("mistake", "false handling", "unsupported action"),
        "موافقة صلاحيات تقرير تدقيق مراجعة قيود محاسبية تصحيحية",
    ),
    (("compare", "advantage", "disadvantage"), "مقارنة مهام وحدة الانذار وحدة البريد والملفات"),
    (("after 2024", "published after"), "2025 2026 تاريخ الإصدار تاريخ آخر مراجعة"),
]


# Arabic ↔ Arabic synonym expansion for pure-Arabic queries
# (the English glossary above only fires when the query contains English keys)
ARABIC_SYNONYMS: list[tuple[tuple[str, ...], str]] = [
    (
        ("مخازن", "مخزن", "المخازن", "المخزن"),
        "مستودعات مستودع المخزون الراكد الموجودات",
    ),
    (
        ("مستودعات", "مستودع", "المستودعات"),
        "مخازن مخزن المخزون",
    ),
    (
        ("إتلاف", "اتلاف", "الإتلاف", "الاتلاف", "بإتلاف", "بالإتلاف"),
        "اتلاف اتلافها محضر اتلاف لجنة الاتلاف عدم الصلاحية",
    ),
    # Monthly schedule appendix (p20): Vanguard / Geovision / دورية / شهري
    # Do NOT mix with the annual engineer-review on p17.
    (
        ("vanguard", "geovision", "دورية", "شهري", "الأوقات المعيارية", "ملحق رقم"),
        "ملحق رقم 1 الاوقات المعيارية لمراجعة Logs Geovision شهري Vanguard شهري الاتصال الالي شهري",
    ),
    (
        ("bpm", "بي بي ام", "نظام الـ bpm", "نظام bpm", "نظام ال bpm", "بي بي إم"),
        "اتمتة عمليات تبادل البريد نظام BPM حلقة وصل بين الفروع "
        "ترحيل مناقلات الموجودات الثابتة خلال يومين عمل "
        "اثبات البريد على نظام اتمتة تبادل البريد "
        "استلام البريد او ارساله فقط ان كان مرحل على نظام اتمتة "
        "مناقلات الموجودات الثابتة يومين عمل استلام السندات",
    ),
    (
        ("جناح الإدارة", "دخول جناح", "صلاحية الموافقة على دخول"),
        "مدير مساعد الإنذار المركزي نائب رئيس مدير الشؤون الإدارية والهندسية "
        "مدير الأمن والإنذار المركزي موافقة دخول جناح الإدارة",
    ),
    (
        ("مدراء الأنظمة الأمنية", "لقطات الـ Logs الخاصة بمدراء", "Logs الخاصة بمدراء"),
        "مراجعة البيانات عينات عشوائية بشكل سنوي كحد أدنى أو حسب الحاجة "
        "مهندس أنظمة أمنية مدراء الأنظمة الأمنية",
    ),
    (
        ("فقدت وحدة البريد", "فقدت", "ضياع مغلف", "مغلف مرسل"),
        "التعامل مع حالات النقص تلف ضياع البريد المرسل المستلم "
        "مخاطبة شركة البريد بيان حجم الضرر مدير المطبعة والمستودعات",
    ),

    (
        ("جرد", "الجرد السنوي", "لجنة الجرد", "فروقات", "أعضاء اللجنة", "اعضاء اللجنة"),
        "اجراءات الجرد السنوي للموجودات الثابتة لجنة الجرد كشوفات الموجودات معالجة الفروقات "
        "مسؤول أول الموجودات أمين مستودع موظف المطبعة مندوب أنظمة المعلومات مندوب مركز العمل "
        "تشكيل اللجنة رئيسا عضو رفع تقرير بنتائج الجرد",
    ),
    (
        ("فقدت", "ضياع", "مغلف", "نقص/تلف", "تلف البريد"),
        "التعامل مع حالات النقص تلف ضياع البريد المرسل المستلم من مراكز العمل",
    ),
    # Annual random-sample review (p17) — ONLY when the question is about
    # security-systems managers/engineers or random samples, NOT every Logs query.
    (
        ("مدراء الأنظمة الأمنية", "مهندس أنظمة أمنية", "مهندس الأنظمة الأمنية", "عينات عشوائية"),
        "مراجعة البيانات عينات عشوائية بشكل سنوي مهندس أنظمة أمنية",
    ),
]


def expand_query(text: str) -> str:
    if not text:
        return text
    lower = text.lower()
    extra: list[str] = []
    for keys, arabic in GLOSSARY:
        if isinstance(keys, str):
            keys = (keys,)
        if any(k in lower for k in keys):
            extra.append(arabic)
    # Arabic synonym expansion (always useful for pure-Arabic procedure questions)
    for keys, arabic in ARABIC_SYNONYMS:
        if any(k in text or k in lower for k in keys):
            extra.append(arabic)

    # Special-case Logs: branch by intent so p17 and p20 don't steal each other.
    # - Vanguard/Geovision/دورية/شهري → monthly appendix (p20)
    # - مدراء/مهندس/عينات → annual sample review (p17) already handled above
    # - bare "Logs" alone → light neutral boost, no "سنوي" injection
    logs_markers = ("log", "logs", "لوج", "لقطات", "سجلات")
    if any(m in lower or m in text for m in logs_markers):
        monthly_intent = any(
            m in lower or m in text
            for m in ("vanguard", "geovision", "دورية", "شهري", "ملحق", "إنذار مبكر", "الانذار المبكر", "الاتصال")
        )
        annual_intent = any(
            m in text
            for m in ("مدراء", "مهندس", "عينات", "عشوائية", "سنوي")
        )
        if monthly_intent and not annual_intent:
            extra.append(
                "ملحق رقم 1 الاوقات المعيارية لمراجعة Logs Geovision شهري Vanguard شهري الاتصال الالي شهري"
            )
        elif annual_intent and not monthly_intent:
            extra.append("مراجعة البيانات عينات عشوائية بشكل سنوي مهندس أنظمة أمنية")
        # else: leave query as-is; hybrid dense+BM25 ranks without bias

    if extra:
        return text + " " + " ".join(dict.fromkeys(extra))
    return text + " إجراءات دليل وحدة"