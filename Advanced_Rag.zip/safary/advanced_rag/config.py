"""Runtime configuration and Gemini list prices (USD per 1M tokens)."""

from __future__ import annotations

import os
from pathlib import Path

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parents[1]
load_dotenv(ROOT / ".env")

DATA_DIR = ROOT / "data" / "corpus"
# Comma-separated PDF filename substrings to skip during ingest.
# Set CORPUS_EXCLUDE=Central Alarm to drop the fire/theft monitoring manual.
CORPUS_EXCLUDE = [
    x.strip()
    for x in os.getenv("CORPUS_EXCLUDE", "").split(",")
    if x.strip()
]
INDEX_DIR = ROOT / "data" / "index"
OUTPUT_DIR = ROOT / "outputs"
REPORT_DIR = ROOT / "reports"

CHUNK_SIZE = int(os.getenv("CHUNK_SIZE", "1100"))
CHUNK_OVERLAP = int(os.getenv("CHUNK_OVERLAP", "180"))
TOP_K = int(os.getenv("TOP_K", "6"))
RERANK_K = int(os.getenv("RERANK_K", "4"))
COMPRESSION_SENTENCES = int(os.getenv("COMPRESSION_SENTENCES", "8"))

# CRAG heuristic decision thresholds against context_relevance_score()
# (0.7*semantic + 0.3*lexical blend, see retrieve.py). Exposed here instead
# of hard-coded so they can be re-tuned per embedding backend without
# touching retrieve.py.
CRAG_CORRECT_THRESHOLD = float(os.getenv("CRAG_CORRECT_THRESHOLD", "0.22"))
CRAG_INCORRECT_THRESHOLD = float(os.getenv("CRAG_INCORRECT_THRESHOLD", "0.12"))

# General low-confidence retrieval retry (see pipeline.py): applies the same
# CRAG-style corrective re-search to ANY route (not just questions the
# router pre-flagged with the "crag" technique), whenever the actual
# retrieved hits score below CRAG_INCORRECT_THRESHOLD. This catches
# OCR-noise-driven weak retrieval on otherwise ordinary factual questions.
# Costs one extra rewrite + search call ONLY when confidence is genuinely
# low, not on every question — but on a quota-limited backend (e.g. a
# rate-limited Groq key) where even occasional extra calls matter, set this
# to 0 to opt out entirely.
AUTO_LOW_CONFIDENCE_RETRY = os.getenv("AUTO_LOW_CONFIDENCE_RETRY", "1") not in ("0", "false", "False")

# Hard safety cap on the total size (characters) of retrieved context
# assembled into the final-generation prompt, independent of TOP_K/
# CHUNK_SIZE/COMPRESSION_SENTENCES math. This exists specifically for
# quota-limited paid backends (e.g. Groq): TOP_K*CHUNK_SIZE alone can still
# add up to more tokens than expected once multi_query/decomposition/hyde
# fan out into several search queries feeding the same context block.
# ~6000 chars is roughly 1500-2000 tokens for mixed Arabic/English text —
# generous for a single factual answer, cheap enough to stay well clear of
# a typical free-tier per-request/per-minute token cap. Lower it further
# (e.g. 3000) if a specific provider's quota is tight.
MAX_CONTEXT_CHARS = int(os.getenv("MAX_CONTEXT_CHARS", "6000"))

# Output token cap for the OpenAI-compatible cloud path (OpenRouter/Groq/
# any provider using the same /chat/completions client in llm.py). Was a
# hardcoded max_tokens=2048 in llm.py; a factual single-answer response
# rarely needs that much, and every extra output token also counts against
# a token-per-minute quota. Lowered default + made configurable.
GENERATION_MAX_TOKENS = int(os.getenv("GENERATION_MAX_TOKENS", "900"))

# Truncation-escalation ceiling for OpenRouter (reasoning models).
GENERATION_MAX_TOKENS_CEILING = int(os.getenv("GENERATION_MAX_TOKENS_CEILING", "6000"))

# --- OCR ingestion ---
# pypdf's native text extraction on these manuals hits a font cmap issue common
# in Arabic PDFs: individual glyphs get substituted (e.g. "الايعاز" -> "الاقعاز",
# "نتيجة" -> "نتينة") even though the page is 100% text (no missing pages).
# Rendering each page to an image and OCRing it with Tesseract's Arabic model
# avoids that substitution and produces measurably cleaner chunks/ground truth.
# Falls back to pypdf automatically if poppler/tesseract binaries aren't installed.
USE_OCR = os.getenv("USE_OCR", "1").strip() not in {"0", "false", "False"}
OCR_LANG = os.getenv("OCR_LANG", "ara+eng").strip()
OCR_DPI = int(os.getenv("OCR_DPI", "300"))
OCR_PSM = os.getenv("OCR_PSM", "3").strip()  # 3 = fully automatic page segmentation
OCR_OEM = os.getenv("OCR_OEM", "1").strip()  # 1 = LSTM engine only
# Minimum share of the page's characters that must be Arabic/Latin letters for
# the extracted text to be trusted; otherwise we fall back to the other method.
MIN_TEXT_QUALITY = 0.35

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "").strip()
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.0-flash").strip()

# --- Ollama (local, self-hosted) generation backend ---
# PRIMARY backend for the *generation/judging* LLM calls (router, rewriter,
# decomposition, HyDE, CRAG, final answer, LLM-as-judge). Requires Ollama
# installed and running locally (`ollama serve`) with both models below
# already pulled ahead of time, e.g.:
#   ollama pull qwen2.5:3b-instruct-q4_K_M
#   ollama pull llama3.2:3b-instruct-q4_K_M
# No API key, no quota, no cost — everything runs on your own CPU/GPU.
# Fully independent of EMBEDDING_BACKEND.
#
# Two DIFFERENT model families are used on purpose, not two quantizations
# of the same one: OLLAMA_GENERATION_MODEL answers the question,
# OLLAMA_JUDGE_MODEL grades that answer for the LLM-as-judge metrics
# (context relevance, faithfulness, answer relevance, correctness). If the
# judge is the exact same weights as the generator, it tends to grade the
# generator's own output more generously (self-preference bias) — using a
# different family catches more of that than sharing weights outright.
OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434").strip()
OLLAMA_GENERATION_MODEL = os.getenv("OLLAMA_GENERATION_MODEL", "qwen2.5:3b-instruct-q4_K_M").strip()
OLLAMA_JUDGE_MODEL = os.getenv("OLLAMA_JUDGE_MODEL", "llama3.2:3b-instruct-q4_K_M").strip()
# Set to 0 to disable the Ollama backend entirely (e.g. if Ollama isn't
# installed on this machine) and drop straight to Claude/Gemini instead.
USE_OLLAMA = os.getenv("USE_OLLAMA", "1").strip() not in {"0", "false", "False"}
# Claude (Anthropic) is the PRIMARY generation/judge backend when token is set.
# Ollama remains available as automatic fallback if Claude errors/rate-limits.
USE_CLAUDE = os.getenv("USE_CLAUDE", "1").strip() not in {"0", "false", "False"}

# --- OpenRouter (OpenAI-compatible) generation backend ---
# Preferred when OPENROUTER_API_KEY is set: far less aggressive content
# filtering than AgentRouter for document-RAG workloads. Uses the standard
# OpenAI chat completions API shape.
OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY", "").strip()
OPENROUTER_BASE_URL = os.getenv(
    "OPENROUTER_BASE_URL", "https://openrouter.ai/api/v1"
).strip().rstrip("/")
OPENROUTER_MODEL = os.getenv(
    "OPENROUTER_MODEL", "anthropic/claude-sonnet-4"
).strip()
OPENROUTER_JUDGE_MODEL = os.getenv(
    "OPENROUTER_JUDGE_MODEL", OPENROUTER_MODEL
).strip()
# HTTP-Referer / X-Title are optional OpenRouter ranking headers.
OPENROUTER_HTTP_REFERER = os.getenv(
    "OPENROUTER_HTTP_REFERER", "https://localhost/advanced-rag-eval"
).strip()
OPENROUTER_APP_TITLE = os.getenv(
    "OPENROUTER_APP_TITLE", "AdvancedRAG-Eval"
).strip()
USE_OPENROUTER = (
    bool(OPENROUTER_API_KEY)
    and os.getenv("USE_OPENROUTER", "1").strip() not in {"0", "false", "False"}
)


# --- Ollama performance tuning ---
# Measured on this project's own machine: a single /api/chat call with a
# realistic RAG-sized context (system + retrieved chunks + question) took
# ~248s on CPU-only inference. The old 180s timeout was shorter than that,
# so calls were timing out mid-prefill, falling back to Claude, and Claude
# was itself out of budget -> silent failure down to the local heuristic.
# None of that was an Ollama/model problem; it's just CPU prefill being
# slow on long prompts. These knobs address the actual bottleneck instead
# of papering over it with an even longer timeout alone.
#
# OLLAMA_TIMEOUT_S: generous ceiling so a real (slow but working) call
# doesn't get killed mid-flight. The baseline (forced basic_rag) path is
# the one most likely to hit this: it retrieves + sends TOP_K chunks of
# real context for EVERY question, including ones that are trivial on the
# routed/advanced path (Q1/Q9 route to "simple" there with zero context,
# but the baseline forces basic_rag on them too, on purpose, to compare
# against). That extra context is what pushes CPU-only prefill time up —
# 600s was measured as "well above" a 248s sample call, but a longer
# baseline context on a slower machine can still exceed it. Raise this
# first if a run still hits timeouts before touching TOP_K/CHUNK_SIZE below.
OLLAMA_TIMEOUT_S = int(os.getenv("OLLAMA_TIMEOUT_S", "900"))
# OLLAMA_NUM_CTX: explicit context window. Ollama's default (often 2048-4096
# depending on model, but some Modelfiles set it much higher) can make the
# server allocate/process more KV-cache than the prompt actually needs.
# Pinning this to a value that comfortably fits "system + compressed
# context + question" avoids over-allocating for headroom you're not using.
# Raise this if you see truncated context errors for longer documents.
OLLAMA_NUM_CTX = int(os.getenv("OLLAMA_NUM_CTX", "4096"))
# OLLAMA_NUM_PREDICT: caps generation length so a run-on completion can't
# add unbounded time after the (already slow) prefill finishes. 512 is
# comfortably more than any router/rewrite/HyDE/answer output should need;
# override higher only if answers are being cut off.
OLLAMA_NUM_PREDICT = int(os.getenv("OLLAMA_NUM_PREDICT", "512"))
# OLLAMA_KEEP_ALIVE: tells the Ollama server to keep the model resident in
# memory for this long after a call instead of unloading it immediately,
# so back-to-back calls in the same eval run (router -> rewrite -> HyDE ->
# CRAG -> generate -> judge, repeated per question) don't each pay a fresh
# model-load cost on top of prefill.
OLLAMA_KEEP_ALIVE = os.getenv("OLLAMA_KEEP_ALIVE", "30m").strip()

# --- Claude (Anthropic protocol, via AgentRouter) generation backend ---
# Fallback only: used automatically if Ollama isn't running/reachable, or
# a specific Ollama call errors out (router, rewriter, multi-query,
# decomposition, HyDE, CRAG, final answer, LLM-as-judge all route through
# this if Ollama fails). Talks to AgentRouter (an Anthropic-protocol-
# compatible endpoint) rather than api.anthropic.com directly — same
# `anthropic` SDK, different base_url/token.
ANTHROPIC_AUTH_TOKEN = os.getenv("ANTHROPIC_AUTH_TOKEN", "").strip()
ANTHROPIC_BASE_URL = os.getenv("ANTHROPIC_BASE_URL", "https://api.anthropic.com").strip()
ANTHROPIC_MODEL = os.getenv("ANTHROPIC_MODEL", "claude-opus-4-8").strip()
# --- Claude rate-limit handling ---
# A single "advanced" question fires ~8 sequential Claude calls (router,
# rewrite, multi-query, decomposition, HyDE, CRAG, rerank, compression,
# final generation) plus one more for the LLM-judge, and run_eval.py runs
# every question twice (advanced + forced basic_rag baseline) back to back
# with zero pacing between calls. That burst is what was tripping 429s —
# _claude_generate used to treat a 429 as a generic per-prompt failure and
# fall straight to the local heuristic for that one call, so a transient
# rate limit silently degraded a chunk of the run to heuristic answers
# instead of real Claude output, without ever slowing down for the *next*
# call either.
# ANTHROPIC_MIN_CALL_INTERVAL_S: minimum seconds enforced between the end
# of one Claude call and the start of the next (self-imposed pacing, so we
# stop bursting into the limit in the first place).
# ANTHROPIC_MAX_RETRIES / ANTHROPIC_RETRY_BASE_DELAY_S: on an actual 429,
# retry with exponential backoff (base_delay * 2**attempt, capped) before
# giving up and falling back to the local heuristic for that call.
ANTHROPIC_MIN_CALL_INTERVAL_S = float(os.getenv("ANTHROPIC_MIN_CALL_INTERVAL_S", "1.0"))
ANTHROPIC_MAX_RETRIES = int(os.getenv("ANTHROPIC_MAX_RETRIES", "5"))
ANTHROPIC_RETRY_BASE_DELAY_S = float(os.getenv("ANTHROPIC_RETRY_BASE_DELAY_S", "2.0"))
ANTHROPIC_RETRY_MAX_DELAY_S = float(os.getenv("ANTHROPIC_RETRY_MAX_DELAY_S", "30.0"))
# Comma-separated alternate model IDs to try when the primary model returns
# content-blocked (AgentRouter often allows a subset of models per plan, and
# some models are stricter on moderation than others).
ANTHROPIC_FALLBACK_MODELS = [
    m.strip()
    for m in os.getenv(
        "ANTHROPIC_FALLBACK_MODELS",
        "claude-opus-5,deepseek-v4-flash,glm-5.3,gpt-5.6-sol",
    ).split(",")
    if m.strip()
]

GEMINI_EMBEDDING_MODEL = os.getenv("GEMINI_EMBEDDING_MODEL", "gemini-embedding-001").strip()
# text-embedding-004 was deprecated by Google on 2026-01-14 and now 404s.
# gemini-embedding-001 is the current GA replacement (confirmed to support
# Arabic). Only relevant if EMBEDDING_BACKEND=gemini (see below).

# --- Dense embedding backend ---
# "bge_m3" -> local BAAI/bge-m3 via sentence-transformers (default).
#             ~2.3GB download (568M-param XLM-RoBERTa-large backbone),
#             multilingual/strong on Arabic, no API key/quota, runs fine
#             on CPU for a corpus this size and is much lighter than an
#             8B decoder model. No query instruction prefix needed — see
#             note below.
# "gemini" -> Google's gemini-embedding-001 API (legacy path, kept for
#             comparison / machines that would rather not download any
#             local model at all).
# "none"   -> disable dense embeddings; retrieval runs on TF-IDF alone
#             (VectorStore.search already fully supports sparse-only mode).
EMBEDDING_BACKEND = os.getenv("EMBEDDING_BACKEND", "bge_m3").strip().lower()

BGE_EMBEDDING_MODEL = os.getenv("BGE_EMBEDDING_MODEL", "BAAI/bge-m3").strip()
BGE_EMBEDDING_DEVICE = os.getenv("BGE_EMBEDDING_DEVICE", "auto").strip()  # auto|cuda|cpu|mps
BGE_EMBEDDING_BATCH_SIZE = int(os.getenv("BGE_EMBEDDING_BATCH_SIZE", "8"))
BGE_EMBEDDING_MAX_LEN = int(os.getenv("BGE_EMBEDDING_MAX_SEQ_LENGTH", "8192"))
# BGE-M3's native dense output is 1024-dim. Unlike Qwen3-Embedding, BGE-M3
# was not published with Matryoshka truncation as a first-class, validated
# feature, so this defaults to 0 (no truncation). Set >0 only if you've
# checked quality holds up for your queries.
BGE_EMBEDDING_DIM = int(os.getenv("BGE_EMBEDDING_DIM", "0"))
# Unlike BGE v1/v1.5 (which needed "Represent this sentence for searching
# relevant passages: " on queries only), BAAI's BGE-M3 model card states no
# instruction prefix is needed for either queries or documents — it's a
# symmetric encoder. So, unlike the old Qwen backend, nothing is prepended
# here; `is_query` is accepted for interface compatibility but unused.

# Back-compat flag: some earlier code/notes referred to this name. Now
# derived from EMBEDDING_BACKEND rather than read independently.
USE_GEMINI_EMBEDDINGS = (
    EMBEDDING_BACKEND == "gemini"
    and os.getenv("USE_GEMINI_EMBEDDINGS", "1").strip() not in {"0", "false", "False"}
)
USE_BGE_EMBEDDINGS = EMBEDDING_BACKEND == "bge_m3"

# Approximate public Gemini 2.0 Flash prices (USD / 1M tokens).
PRICE_TABLE = {
    "gemini-2.0-flash": {"input": 0.10, "output": 0.40},
    "gemini-2.0-flash-lite": {"input": 0.075, "output": 0.30},
    "gemini-1.5-flash": {"input": 0.075, "output": 0.30},
    "gemini-1.5-pro": {"input": 1.25, "output": 5.00},
    "text-embedding-004": {"input": 0.00, "output": 0.00},
    "local-heuristic": {"input": 0.00, "output": 0.00},
    "bm25-local": {"input": 0.00, "output": 0.00},
    # NOTE: "claude-opus-4-8" is not a published Anthropic model — it's the
    # name AgentRouter exposes for this project's token. Priced here at
    # Anthropic's standard Claude Opus list rate ($15/$75 per 1M tokens) as
    # a placeholder; check your AgentRouter dashboard/invoice for the actual
    # billed rate and correct this if it differs.
    "claude-opus-4-8": {"input": 15.00, "output": 75.00},
    # OpenRouter model ids — approximate; check openrouter.ai/models for live rates.
    "anthropic/claude-sonnet-4": {"input": 3.00, "output": 15.00},
    "anthropic/claude-opus-4": {"input": 15.00, "output": 75.00},
    "openai/gpt-4o-mini": {"input": 0.15, "output": 0.60},
    "google/gemini-2.0-flash-001": {"input": 0.10, "output": 0.40},
    "nvidia/nemotron-3-super-120b-a12b:free": {"input": 0.00, "output": 0.00},
    "nvidia/nemotron-3-ultra-550b-a55b:free": {"input": 0.00, "output": 0.00},
    "google/gemma-4-31b-it:free": {"input": 0.00, "output": 0.00},
    "openrouter/free": {"input": 0.00, "output": 0.00},
    # Local models: no per-token API cost. Compute cost is real (CPU/GPU
    # time) but isn't billed per-token, so it's tracked at $0 like other
    # local steps and called out separately in latency instead. Ollama's
    # generation/judge model tags are user-configurable (whatever you
    # `ollama pull`ed), so rather than listing every possible tag here,
    # llm.py's LLMClient.generate() short-circuits cost to $0.0 directly
    # whenever the Ollama backend served the call, instead of doing a
    # PRICE_TABLE lookup for it.
    "bge-m3-local": {"input": 0.00, "output": 0.00},
}


def estimate_cost(model: str, input_tokens: int, output_tokens: int) -> float:
    """Estimate USD cost from token counts.

    Free-tier / local models list at $0, which collapses the Cost column to
    0.000000 for every question and hides simple-vs-advanced differences.
    When the looked-up rate is zero we fall back to Gemini 2.0 Flash list
    rates so the evaluation still reports a meaningful estimated cost while
    remaining comparable across routes. Actual billed cost for free models
    is still $0.
    """
    rates = PRICE_TABLE.get(model, PRICE_TABLE["gemini-2.0-flash"])
    inp_rate = rates["input"]
    out_rate = rates["output"]
    if inp_rate == 0.0 and out_rate == 0.0:
        proxy = PRICE_TABLE["gemini-2.0-flash"]
        inp_rate, out_rate = proxy["input"], proxy["output"]
    return (input_tokens / 1_000_000) * inp_rate + (output_tokens / 1_000_000) * out_rate
