"""Local dense embeddings via BAAI/bge-m3.

Replaces the earlier Qwen3-Embedding-8B backend, which was too heavy for
routine use (8B decoder params, ~15GB download, requires a beefy GPU to be
fast). BGE-M3 is a 568M-param XLM-RoBERTa-large-based encoder — roughly
2.3GB — multilingual, strong on Arabic, and fast enough on CPU for a
corpus of a few hundred chunks, while still giving good dense retrieval
quality. It also removes the free-tier quota problem the original Gemini
backend had (see README changelog).

Two things are deliberately different from the old Qwen module, both
called out on BAAI's model card:
  * No instruction prefix. BGE-M3 (unlike BGE v1/v1.5, and unlike
    Qwen3-Embedding) is a *symmetric* encoder: queries and documents are
    embedded the same way, with nothing prepended. `is_query` is kept in
    this module's signature only so `llm.py`/`pipeline.py` don't need an
    if-branch per backend — it's a no-op here.
  * No `tokenizer_kwargs={"padding_side": "left"}`. That was needed for
    Qwen3-Embedding because it's a causal/decoder-style model. BGE-M3 is a
    bidirectional encoder (no causal mask), so left-padding isn't required
    — passing it anyway is also what triggered the
    "tokenizer_kwargs ... deprecated, use processor_kwargs" warning seen
    with newer sentence-transformers releases. Simplest fix: don't pass it.

The model is loaded lazily (first call) and cached as a process-wide
singleton so `store.py` (indexing, many chunks) and `pipeline.py` (one
query at a time) share the same loaded weights instead of reloading the
model repeatedly.
"""

from __future__ import annotations

import threading

import numpy as np

from advanced_rag.config import (
    BGE_EMBEDDING_BATCH_SIZE,
    BGE_EMBEDDING_DEVICE,
    BGE_EMBEDDING_DIM,
    BGE_EMBEDDING_MAX_LEN,
    BGE_EMBEDDING_MODEL,
)

_model = None
_model_lock = threading.Lock()
_load_error: Exception | None = None


def _get_model():
    """Lazily load and cache the SentenceTransformer-wrapped BGE-M3 model."""
    global _model, _load_error
    if _model is not None:
        return _model
    if _load_error is not None:
        # Don't retry a slow, doomed load (e.g. missing dependency) on every call.
        raise _load_error
    with _model_lock:
        if _model is not None:
            return _model
        try:
            from sentence_transformers import SentenceTransformer
        except ImportError as exc:  # pragma: no cover - environment-dependent
            _load_error = RuntimeError(
                "sentence-transformers (and torch) are required for the local "
                "BGE-M3 backend. Install with:\n"
                "    pip install -U sentence-transformers torch\n"
                "or set EMBEDDING_BACKEND=gemini / EMBEDDING_BACKEND=none in .env "
                "to use a different backend."
            )
            raise _load_error from exc

        device = None if BGE_EMBEDDING_DEVICE == "auto" else BGE_EMBEDDING_DEVICE
        extra_kwargs = {}
        if BGE_EMBEDDING_DIM:
            # Not officially validated for BGE-M3 (see config.py note); off by default.
            extra_kwargs["truncate_dim"] = BGE_EMBEDDING_DIM

        try:
            model = SentenceTransformer(
                BGE_EMBEDDING_MODEL,
                device=device,
                trust_remote_code=True,
                **extra_kwargs,
            )
        except Exception as exc:  # noqa: BLE001 - surface a clear, actionable message
            _load_error = RuntimeError(
                f"Failed to load {BGE_EMBEDDING_MODEL!r} via sentence-transformers. "
                "Check your internet connection / Hugging Face access, or lower "
                "BGE_EMBEDDING_BATCH_SIZE / switch EMBEDDING_BACKEND in .env. "
                f"Original error: {exc}"
            )
            raise _load_error from exc

        model.max_seq_length = BGE_EMBEDDING_MAX_LEN
        _model = model
    return _model


def is_available() -> bool:
    """True if the local BGE-M3 model can be loaded in this environment."""
    try:
        _get_model()
        return True
    except Exception:
        return False


def embed(texts: list[str], is_query: bool = False, batch_size: int | None = None) -> list[list[float]]:
    """Embed a batch of texts with BGE-M3.

    `is_query` is accepted for interface parity with other backends but is
    unused: BGE-M3 needs no instruction prefix for either queries or
    documents (see module docstring).
    """
    if not texts:
        return []
    model = _get_model()
    vectors = model.encode(
        list(texts),
        batch_size=batch_size or BGE_EMBEDDING_BATCH_SIZE,
        normalize_embeddings=True,
        convert_to_numpy=True,
        show_progress_bar=False,
    )
    return np.asarray(vectors, dtype=np.float32).tolist()
