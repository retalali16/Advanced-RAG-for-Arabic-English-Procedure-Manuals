"""PDF ingestion, OCR, chunking, and metadata extraction for the three manuals.

Extraction strategy (per page):
1. Try Tesseract OCR on a rendered page image (ara+eng, psm 3, oem 1). This
   avoids a font-cmap glyph-substitution bug that corrupts pypdf's native text
   extraction on these particular PDFs (see MIN_TEXT_QUALITY note below).
2. Score both the OCR text and the pypdf text with a cheap "is this readable
   Arabic/English text" heuristic and keep whichever is better.
3. If Tesseract/poppler are not installed, or OCR produced nothing usable,
   fall back to pypdf silently so the pipeline still runs.

Chunking strategy:
Manuals are written as numbered procedure steps ("1- ...", "2-] ...") and
short paragraphs, not prose. Blindly slicing by character windows (the old
approach) routinely cut a step in half and mixed unrelated steps together,
which then corrupted retrieval and made it impossible to write trustworthy
ground-truth answers. The new chunker splits on paragraph/step boundaries
first, then greedily packs whole paragraphs into ~CHUNK_SIZE windows with a
one-paragraph overlap, and only hard-splits a single paragraph by sentence if
that paragraph alone exceeds the window.
"""

from __future__ import annotations

import hashlib
import json
import re
import shutil
import subprocess
import tempfile
from dataclasses import asdict, dataclass
from pathlib import Path

from pypdf import PdfReader

from advanced_rag.config import (
    CHUNK_OVERLAP,
    CHUNK_SIZE,
    CORPUS_EXCLUDE,
    DATA_DIR,
    INDEX_DIR,
    MIN_TEXT_QUALITY,
    OCR_DPI,
    OCR_LANG,
    OCR_OEM,
    OCR_PSM,
    ROOT,
    USE_OCR,
)


MANUAL_META = {
    "Assets and wearhouse operation Tasks and Procedures Manual.pdf": {
        "unit": "Assets and Warehouse Operations",
        "doc_type": "procedures_manual",
        "aliases": ["warehouse", "assets", "wearhouse", "inventory"],
    },
    "Central Alarm Tasks And Procedures Manual.pdf": {
        "unit": "Central Alarm",
        "doc_type": "procedures_manual",
        "aliases": ["alarm", "security", "monitoring"],
    },
    "Central Mail and Files Unit Procedures Manual.pdf": {
        "unit": "Central Mail and Files Unit",
        "doc_type": "procedures_manual",
        "aliases": ["mail", "files", "records", "cmu"],
    },
}


@dataclass
class Chunk:
    chunk_id: str
    doc_id: str
    source: str
    unit: str
    page: int
    year: int | None
    years: list[int]
    text: str
    char_start: int
    char_end: int
    extraction_method: str = "pypdf"


def find_pdfs() -> list[Path]:
    candidates = []
    for folder in [DATA_DIR, ROOT]:
        if folder.exists():
            candidates.extend(sorted(folder.glob("*.pdf")))
    unique = {}
    for p in candidates:
        unique[p.name] = p
    pdfs = list(unique.values())
    if CORPUS_EXCLUDE:
        kept = []
        for p in pdfs:
            if any(excl.lower() in p.name.lower() for excl in CORPUS_EXCLUDE):
                print(f"[ingest] EXCLUDED by CORPUS_EXCLUDE: {p.name}")
                continue
            kept.append(p)
        pdfs = kept
    return pdfs


def _years_from_text(text: str) -> list[int]:
    years = sorted({int(y) for y in re.findall(r"\b(19\d{2}|20[0-2]\d)\b", text)})
    return [y for y in years if 1990 <= y <= 2026]


def _year_from_pdf_meta(reader: PdfReader) -> int | None:
    meta = reader.metadata
    if not meta:
        return None
    for attr in ("creation_date", "modification_date"):
        value = getattr(meta, attr, None)
        if value is None:
            continue
        text = str(value)
        found = _years_from_text(text)
        if found:
            return found[-1]
    return None


def _clean_page_text(text: str) -> str:
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def _text_quality(text: str) -> float:
    """Fraction of non-whitespace characters that are Arabic or Latin letters/digits.

    Garbled OCR/cmap output shows up as a low score here (lots of stray
    punctuation, boxes, or single reversed-case Latin fragments).
    """
    stripped = re.sub(r"\s+", "", text)
    if not stripped:
        return 0.0
    good = len(re.findall(r"[A-Za-z\u0600-\u06FF0-9]", stripped))
    return good / len(stripped)


# --- OCR helpers -----------------------------------------------------------

_OCR_TOOLS_CHECKED = False
_OCR_AVAILABLE = False


def _ocr_available() -> bool:
    global _OCR_TOOLS_CHECKED, _OCR_AVAILABLE
    if not _OCR_TOOLS_CHECKED:
        _OCR_AVAILABLE = bool(shutil.which("pdftoppm")) and bool(shutil.which("tesseract"))
        _OCR_TOOLS_CHECKED = True
    return _OCR_AVAILABLE


def _ocr_pdf_pages(pdf_path: Path, page_count: int) -> dict[int, str]:
    """Render every page of the PDF and OCR it. Returns {page_num: text}.

    Uses one pdftoppm invocation for the whole file (much faster than one
    process per page), then one tesseract call per rendered image.
    """
    results: dict[int, str] = {}
    if not _ocr_available():
        return results
    with tempfile.TemporaryDirectory(prefix="rag_ocr_") as tmp:
        tmp_dir = Path(tmp)
        prefix = tmp_dir / "page"
        try:
            subprocess.run(
                [
                    "pdftoppm",
                    "-png",
                    "-r",
                    str(OCR_DPI),
                    str(pdf_path),
                    str(prefix),
                ],
                check=True,
                capture_output=True,
                timeout=600,
            )
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired, OSError):
            return results

        images = sorted(tmp_dir.glob("page-*.png"))
        for img in images:
            m = re.search(r"page-0*(\d+)\.png$", img.name)
            if not m:
                continue
            page_num = int(m.group(1))
            try:
                proc = subprocess.run(
                    [
                        "tesseract",
                        str(img),
                        "stdout",
                        "-l",
                        OCR_LANG,
                        "--psm",
                        OCR_PSM,
                        "--oem",
                        OCR_OEM,
                    ],
                    check=True,
                    capture_output=True,
                    timeout=120,
                )
                text = proc.stdout.decode("utf-8", errors="replace")
            except (subprocess.CalledProcessError, subprocess.TimeoutExpired, OSError):
                text = ""
            results[page_num] = _clean_page_text(text)
    return results


def extract_pdf(path: Path) -> tuple[str, list[tuple[int, str]], int | None, dict[int, str]]:
    """Returns (full_text, [(page_num, text)], meta_year, {page_num: method})."""
    reader = PdfReader(str(path))
    n_pages = len(reader.pages)

    pypdf_pages: dict[int, str] = {}
    for i, page in enumerate(reader.pages, start=1):
        pypdf_pages[i] = _clean_page_text(page.extract_text() or "")

    ocr_pages: dict[int, str] = _ocr_pdf_pages(path, n_pages) if USE_OCR else {}

    pages: list[tuple[int, str]] = []
    methods: dict[int, str] = {}
    for i in range(1, n_pages + 1):
        candidates = []
        if i in ocr_pages and ocr_pages[i].strip():
            candidates.append(("ocr", ocr_pages[i]))
        if i in pypdf_pages and pypdf_pages[i].strip():
            candidates.append(("pypdf", pypdf_pages[i]))
        if not candidates:
            pages.append((i, ""))
            methods[i] = "none"
            continue
        # Prefer OCR when quality is comparable; it avoids the cmap
        # glyph-substitution bug. Only fall back to pypdf if OCR quality is
        # clearly worse (e.g. OCR choked on a diagram-heavy page).
        best_method, best_text = max(candidates, key=lambda c: _text_quality(c[1]))
        if best_method == "pypdf" and "ocr" in dict(candidates):
            ocr_text = dict(candidates)["ocr"]
            if _text_quality(ocr_text) >= MIN_TEXT_QUALITY:
                best_method, best_text = "ocr", ocr_text
        pages.append((i, best_text))
        methods[i] = best_method

    parts = [f"\n\n[Page {p}]\n{t}" for p, t in pages]
    full_text = "\n".join(parts).strip()
    return full_text, pages, _year_from_pdf_meta(reader), methods


# --- Structure-aware chunking ----------------------------------------------

_STEP_MARKER = re.compile(r"^\s*(?:\(?\d{1,2}\)?[-.\]]|[-•])\s*")
_SENT_SPLIT = re.compile(r"(?<=[.!?؟])\s+")


def _split_paragraphs(text: str) -> list[str]:
    """Split page text into paragraph/step units.

    A new unit starts at a blank line OR at a numbered-step marker
    ("1-", "2-]", "3.") at the start of a line, since that's how these
    manuals delimit individual procedure steps.
    """
    raw_lines = text.split("\n")
    paragraphs: list[str] = []
    current: list[str] = []

    def flush():
        if current:
            piece = " ".join(l.strip() for l in current if l.strip())
            if piece:
                paragraphs.append(piece)
            current.clear()

    for line in raw_lines:
        if not line.strip():
            flush()
            continue
        if _STEP_MARKER.match(line) and current:
            flush()
        current.append(line)
    flush()
    return paragraphs


def _split_long_paragraph(paragraph: str, size: int) -> list[str]:
    if len(paragraph) <= size:
        return [paragraph]
    sentences = _SENT_SPLIT.split(paragraph)
    if len(sentences) <= 1:
        # No sentence boundaries at all (rare OCR run-on) - hard wrap.
        return [paragraph[i : i + size] for i in range(0, len(paragraph), size)]
    pieces: list[str] = []
    buf = ""
    for sent in sentences:
        if buf and len(buf) + 1 + len(sent) > size:
            pieces.append(buf)
            buf = sent
        else:
            buf = f"{buf} {sent}".strip()
    if buf:
        pieces.append(buf)
    return pieces


def chunk_page_text(text: str, size: int = CHUNK_SIZE, overlap: int = CHUNK_OVERLAP) -> list[tuple[str, int, int]]:
    """Pack whole paragraphs/steps into ~size windows with a small paragraph overlap.

    Returns a list of (chunk_text, char_start, char_end) using offsets into
    the original page text so downstream code can still locate a chunk on
    the page if needed.
    """
    if not text.strip():
        return []

    units: list[str] = []
    for para in _split_paragraphs(text):
        units.extend(_split_long_paragraph(para, size))

    chunks: list[tuple[str, int, int]] = []
    buf_units: list[str] = []
    buf_len = 0

    def flush(start_offset: int) -> int:
        nonlocal buf_units, buf_len
        if not buf_units:
            return start_offset
        piece = "\n".join(buf_units).strip()
        end_offset = start_offset + len(piece)
        if len(piece) > 80:
            chunks.append((piece, start_offset, end_offset))
        buf_units = []
        buf_len = 0
        return end_offset

    start_offset = 0
    for unit in units:
        if buf_len and buf_len + len(unit) + 1 > size:
            start_offset = flush(start_offset)
            # carry the last unit forward as overlap context
            if overlap > 0 and chunks:
                tail = chunks[-1][0]
                carried = tail[-overlap:]
                buf_units = [carried]
                buf_len = len(carried)
        buf_units.append(unit)
        buf_len += len(unit) + 1
    flush(start_offset)
    return chunks


def ingest() -> list[Chunk]:
    pdfs = find_pdfs()
    if not pdfs:
        raise FileNotFoundError("No PDF manuals found in data/corpus or project root.")
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    INDEX_DIR.mkdir(parents=True, exist_ok=True)

    ocr_ok = USE_OCR and _ocr_available()
    print(f"[ingest] OCR enabled={USE_OCR} available={_ocr_available()} -> using_ocr={ocr_ok}")

    all_chunks: list[Chunk] = []
    inventory = []
    for pdf in pdfs:
        extra = MANUAL_META.get(pdf.name, {"unit": pdf.stem, "doc_type": "manual", "aliases": []})
        full_text, pages, meta_year, methods = extract_pdf(pdf)
        doc_years = _years_from_text(full_text)
        if meta_year:
            doc_years = sorted(set(doc_years + [meta_year]))
        doc_year = meta_year or (doc_years[-1] if doc_years else None)
        doc_id = hashlib.md5(pdf.name.encode()).hexdigest()[:10]

        method_counts: dict[str, int] = {}
        chunk_i = 0
        for page_num, text in pages:
            method_counts[methods.get(page_num, "none")] = method_counts.get(methods.get(page_num, "none"), 0) + 1
            if not text:
                continue
            for piece, c0, c1 in chunk_page_text(text):
                chunk_i += 1
                local_years = _years_from_text(piece) or doc_years
                chunk_year = local_years[-1] if local_years else doc_year
                chunk = Chunk(
                    chunk_id=f"chunk_{doc_id}_{page_num}_{chunk_i}",
                    doc_id=doc_id,
                    source=pdf.name,
                    unit=extra["unit"],
                    page=page_num,
                    year=chunk_year,
                    years=local_years,
                    text=piece,
                    char_start=c0,
                    char_end=c1,
                    extraction_method=methods.get(page_num, "none"),
                )
                all_chunks.append(chunk)

        dest = DATA_DIR / pdf.name
        if pdf.resolve() != dest.resolve():
            dest.write_bytes(pdf.read_bytes())
        n_chunks = sum(1 for c in all_chunks if c.source == pdf.name)
        inventory.append(
            {
                "source": pdf.name,
                "unit": extra["unit"],
                "pages": len(pages),
                "chunks": n_chunks,
                "years": doc_years,
                "meta_year": meta_year,
                "extraction_methods": method_counts,
                "preview": full_text[:2500],
            }
        )
        print(f"[ingest] {pdf.name}: {len(pages)} pages -> {n_chunks} chunks; methods={method_counts}")

    (INDEX_DIR / "chunks.json").write_text(
        json.dumps([asdict(c) for c in all_chunks], ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    (INDEX_DIR / "inventory.json").write_text(json.dumps(inventory, ensure_ascii=False, indent=2), encoding="utf-8")
    preview = "\n\n====\n\n".join(f"{item['source']}\n{item['preview']}" for item in inventory)
    (INDEX_DIR / "corpus_preview.txt").write_text(preview, encoding="utf-8")
    return all_chunks
