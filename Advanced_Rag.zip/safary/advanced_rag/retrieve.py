"""Retrieval upgrades: fusion, reranking, compression, CRAG."""

from __future__ import annotations

import re
from collections import defaultdict

from advanced_rag.bilingual import expand_query
from advanced_rag.config import (
    COMPRESSION_SENTENCES,
    CRAG_CORRECT_THRESHOLD,
    CRAG_INCORRECT_THRESHOLD,
    RERANK_K,
    TOP_K,
)
from advanced_rag.cost import CostTracker
from advanced_rag.llm import LLMClient
from advanced_rag.router import _parse_json
from advanced_rag.store import Hit, VectorStore


def rrf_merge(hit_lists: list[list[Hit]], k: int = TOP_K, k_rrf: int = 60) -> list[Hit]:
    scores: dict[str, float] = defaultdict(float)
    best: dict[str, Hit] = {}
    for hits in hit_lists:
        for hit in hits:
            scores[hit.chunk.chunk_id] += 1.0 / (k_rrf + hit.rank)
            if hit.chunk.chunk_id not in best or hit.score > best[hit.chunk.chunk_id].score:
                best[hit.chunk.chunk_id] = hit
    ranked = sorted(scores.items(), key=lambda x: x[1], reverse=True)
    out = []
    for i, (cid, score) in enumerate(ranked[:k], start=1):
        hit = best[cid]
        out.append(Hit(chunk=hit.chunk, score=float(score), rank=i, method="rrf"))
    return out


def terms(text: str, expand: bool = False) -> set[str]:
    """Tokenize into a term set.

    FIX (issue #5): `expand_query()` bridges an ENGLISH query to extra
    ARABIC glossary vocabulary so it can be matched against the (mostly
    Arabic) corpus — it is a query-side helper, not a general text
    normalizer. The old code called it unconditionally, including on every
    document chunk. `expand_query()`'s glossary keys are English phrases
    ("warehouse", "alarm", ...); an Arabic chunk almost never contains those
    English keys, so the glossary branch never fires for chunk text, and the
    function falls through to its final `else` — which appends the SAME
    generic filler ("إجراءات دليل وحدة" = "procedures manual unit") to every
    single chunk with no matching keyword. That means every chunk's term set
    picked up 3 identical boilerplate words, uniformly inflating lexical
    overlap for any question whose Arabic-glossary expansion includes those
    words — pure noise, and it silently rewarded chunks that share nothing
    real with the question. Fix: only expand when `expand=True`, and only
    ever pass that for the QUESTION side; document/chunk/sentence text is
    tokenized as-is.
    """
    src = expand_query(text) if expand else (text or "")
    return set(re.findall(r"[A-Za-z\u0600-\u06FF]{3,}", src.lower()))


def keyword_rerank(question: str, hits: list[Hit], k: int = RERANK_K) -> list[Hit]:
    q_terms = terms(question, expand=True)
    scored = []
    for hit in hits:
        overlap = len(q_terms & terms(hit.chunk.text)) / (len(q_terms) + 1e-9)
        scored.append((0.6 * hit.score + 0.4 * overlap, hit))
    scored.sort(key=lambda x: x[0], reverse=True)
    out = []
    for i, (score, hit) in enumerate(scored[:k], start=1):
        out.append(Hit(chunk=hit.chunk, score=float(score), rank=i, method="rerank"))
    return out


def llm_rerank(question: str, hits: list[Hit], llm: LLMClient, tracker: CostTracker, k: int = RERANK_K) -> list[Hit]:
    """LLM reranking with a keyword-rerank fallback for any IDs it omits.

    FIX (issue #8): the old code silently blended an LLM ranking with a
    keyword-based fill-in whenever the LLM returned fewer IDs than there
    were candidate hits, then labelled EVERY resulting hit `method="llm_rerank"`
    — including the ones that were actually placed by the lexical fallback.
    That made a hybrid ranking look like a pure LLM ranking in the notes/
    logs, which is misleading when debugging why a particular chunk did or
    didn't get promoted. Behavior (final order) is unchanged; only the
    reported `method` per hit now says which mechanism actually placed it.
    """
    if not hits:
        return []
    listing = "\n".join(f"{h.chunk.chunk_id}: {h.chunk.text[:400]}" for h in hits)
    system = "Rerank chunks for the question. JSON: {\"ranked_ids\": [\"chunk_...\"]}"
    raw = llm.generate(f"Question: {question}\nChunks:\n{listing}", tracker, step="rerank", system=system, json_mode=True)
    parsed = _parse_json(raw) or {}
    ids = parsed.get("ranked_ids") or []
    by_id = {h.chunk.chunk_id: h for h in hits}

    if not ids:
        # LLM gave no usable ranking at all -> pure keyword rerank.
        return keyword_rerank(question, hits, k=k)

    ordered: list[Hit] = []
    seen: set[str] = set()
    for cid in ids:
        if cid in by_id and cid not in seen:
            ordered.append(by_id[cid])
            seen.add(cid)
    n_from_llm = len(ordered)
    for h in keyword_rerank(question, hits, k=len(hits)):
        if h.chunk.chunk_id not in seen:
            ordered.append(h)
            seen.add(h.chunk.chunk_id)

    out = []
    for i, h in enumerate(ordered[:k], start=1):
        method = "llm_rerank" if i <= n_from_llm else "llm_rerank_fill"
        out.append(Hit(chunk=h.chunk, score=h.score, rank=i, method=method))
    return out


def compress_hits(question: str, hits: list[Hit], llm: LLMClient, tracker: CostTracker, use_llm: bool) -> tuple[str, int, int]:
    raw_context = format_hits(hits)
    original_tokens = max(1, len(raw_context) // 4)
    # Was `use_llm and llm.use_gemini` — pipeline.py always passed
    # `use_llm=self.llm.use_gemini` too, so this was double-gated on a flag
    # that's always False with Ollama as the backend. Compression silently
    # ran the local sentence-overlap heuristic every time and never actually
    # called Ollama. `use_real_llm` covers Ollama/Claude/Gemini.
    if use_llm and llm.use_real_llm:
        system = (
            "Compress the context to only sentences needed to answer the question. "
            "Keep chunk IDs. Do not add facts."
        )
        compressed = llm.generate(
            f"Question: {question}\nContext:\n{raw_context}",
            tracker,
            step="compression",
            system=system,
        )
    else:
        tracker.mark_skipped("compression_llm")
        sentences = []
        q_terms = terms(question, expand=True)
        for hit in hits:
            parts = re.split(r"(?<=[.!?؟])\s+", hit.chunk.text)
            if len(parts) <= 1:
                parts = [hit.chunk.text]
            for sent in parts:
                overlap = len(q_terms & terms(sent))
                if overlap >= 1:
                    sentences.append((overlap, f"[{hit.chunk.chunk_id}] {sent.strip()}"))
        sentences.sort(reverse=True)
        picked = [s for _, s in sentences[:COMPRESSION_SENTENCES]]
        compressed = "\n".join(picked) if picked else raw_context
    new_tokens = max(1, len(compressed) // 4)
    return compressed, original_tokens, new_tokens


def context_relevance_score(question: str, hits: list[Hit]) -> float:
    """Blend retrieval similarity (semantic) with lexical term overlap.

    FIX (issues #3 / #4 / #6 / #7): this was 100% keyword overlap, which is
    exactly the wrong metric for the semantic-mismatch cases HyDE/CRAG exist
    to handle. Example from the assignment itself (Q6): the question says
    "reduce mistakes, false handling, unsupported actions"; the manual says
    "corrective accounting entry", "count committee", "reconciliation". Word
    overlap ~0 even though the chunk is exactly the right one — and since
    CRAG's correct/incorrect/ambiguous decision AND the reranker both leaned
    on this same score, a good semantic retrieval could get marked
    "incorrect" and trigger a needless corrective retry, or get out-ranked by
    a worse, more keyword-y chunk.
    `hit.score` is the retriever's own dense-embedding (and/or BM25) cosine
    similarity, already computed once per chunk in store.py — it recognizes
    that kind of paraphrase/synonym match. Reusing it here costs nothing
    extra and gives CRAG/rerank/relevance a real semantic signal instead of
    only literal word overlap; lexical overlap is kept as a secondary,
    30%-weighted confirmation signal rather than the whole score.
    """
    if not hits:
        return 0.0
    q_terms = terms(question, expand=True)
    top = hits[:4]
    semantic = [max(0.0, min(1.0, h.score)) for h in top]
    lexical = (
        [len(q_terms & terms(h.chunk.text)) / len(q_terms) for h in top]
        if q_terms
        else [0.0] * len(top)
    )
    sem_avg = sum(semantic) / len(semantic)
    lex_avg = sum(lexical) / len(lexical)
    return float(0.7 * sem_avg + 0.3 * lex_avg)


def crag_evaluate(
    question: str,
    hits: list[Hit],
    llm: LLMClient,
    tracker: CostTracker,
) -> dict:
    heuristic = context_relevance_score(question, hits)
    decision = (
        "correct"
        if heuristic >= CRAG_CORRECT_THRESHOLD
        else ("incorrect" if heuristic < CRAG_INCORRECT_THRESHOLD else "ambiguous")
    )
    result = {"decision": decision, "score": round(heuristic, 3), "reason": "term-overlap heuristic"}
    # Was `llm.use_gemini` — same stale gate as rewrite/compression above.
    # CRAG's corrective retry (pipeline.py) already ran off the heuristic
    # decision either way, but the LLM-as-evaluator step itself never
    # actually asked Ollama; `use_real_llm` fixes that.
    if llm.use_real_llm:
        listing = "\n".join(f"{h.chunk.chunk_id}: {h.chunk.text[:350]}" for h in hits)
        system = (
            "You are a Corrective RAG retrieval evaluator. Decide if retrieved docs can answer the question. "
            "JSON: {\"decision\": \"correct|incorrect|ambiguous\", \"score\": 0-1, \"reason\": \"...\"}"
        )
        raw = llm.generate(f"Question: {question}\nDocs:\n{listing}", tracker, step="crag", system=system, json_mode=True)
        parsed = _parse_json(raw)
        if parsed and parsed.get("decision") in {"correct", "incorrect", "ambiguous"}:
            result = parsed
    else:
        tracker.mark_skipped("crag_llm")
    return result


def format_hits(hits: list[Hit]) -> str:
    blocks = []
    for h in hits:
        c = h.chunk
        header = f"[{c.chunk_id}] source={c.source} unit={c.unit} page={c.page} year={c.year}"
        blocks.append(f"{header}\n{c.text}")
    return "\n\n".join(blocks)
