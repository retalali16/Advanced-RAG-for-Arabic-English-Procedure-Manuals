"""Per-call and per-question token/cost/latency tracking."""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any


@dataclass
class LLMCall:
    step: str
    model: str
    input_tokens: int
    output_tokens: int
    cost_usd: float
    latency_s: float
    executed: bool = True


@dataclass
class CostTracker:
    calls: list[LLMCall] = field(default_factory=list)

    def record(
        self,
        step: str,
        model: str,
        input_tokens: int,
        output_tokens: int,
        cost_usd: float,
        latency_s: float,
        executed: bool = True,
    ) -> LLMCall:
        call = LLMCall(step, model, input_tokens, output_tokens, cost_usd, latency_s, executed)
        self.calls.append(call)
        return call

    def mark_skipped(self, step: str) -> None:
        self.calls.append(
            LLMCall(
                step=step,
                model="-",
                input_tokens=0,
                output_tokens=0,
                cost_usd=0.0,
                latency_s=0.0,
                executed=False,
            )
        )

    @property
    def total_cost(self) -> float:
        return sum(c.cost_usd for c in self.calls if c.executed)

    @property
    def total_latency(self) -> float:
        return sum(c.latency_s for c in self.calls if c.executed)

    @property
    def total_input_tokens(self) -> int:
        return sum(c.input_tokens for c in self.calls if c.executed)

    @property
    def total_output_tokens(self) -> int:
        return sum(c.output_tokens for c in self.calls if c.executed)

    def breakdown(self) -> list[dict[str, Any]]:
        return [
            {
                "step": c.step,
                "model": c.model,
                "input_tokens": c.input_tokens,
                "output_tokens": c.output_tokens,
                "cost_usd": round(c.cost_usd, 8),
                "latency_s": round(c.latency_s, 4),
                "executed": c.executed,
            }
            for c in self.calls
        ]


class Timer:
    def __enter__(self):
        self.start = time.perf_counter()
        return self

    def __exit__(self, *args):
        self.elapsed = time.perf_counter() - self.start
