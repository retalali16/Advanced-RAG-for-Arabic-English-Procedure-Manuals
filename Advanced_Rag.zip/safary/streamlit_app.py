"""Streamlit chat UI on top of the existing advanced_rag pipeline.

Uses the SAME RAGPipeline / LLMClient / VectorStore as run_eval.py and
ask.py -- no new logic, just a chat front-end over pipeline.run().
"""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import streamlit as st

from advanced_rag.config import INDEX_DIR
from advanced_rag.ingest import ingest
from advanced_rag.llm import LLMClient
from advanced_rag.pipeline import RAGPipeline
from advanced_rag.store import VectorStore
from advanced_rag.evaluate import evaluate_answer
from advanced_rag.cost import CostTracker

st.set_page_config(page_title="Housing Bank Manuals — RAG Chat", page_icon="\U0001F4C4", layout="wide")


@st.cache_resource(show_spinner=False)
def load_pipeline() -> tuple[RAGPipeline, str]:
    chunks_path = INDEX_DIR / "chunks.json"
    bm25_path = INDEX_DIR / "bm25.pkl"
    if not chunks_path.exists() or not bm25_path.exists():
        ingest()
    llm = LLMClient()
    store = VectorStore.load(llm)
    pipeline = RAGPipeline(store, llm)
    return pipeline, llm.model


with st.spinner("Loading index and model (first load only)..."):
    pipeline, model_name = load_pipeline()

st.title("\U0001F4C4 Housing Bank Manuals — RAG Chat")
st.caption(f"Backend model: `{model_name}` — routing: simple / basic_rag / advanced_rag")

if "chat_history" not in st.session_state:
    st.session_state.chat_history = []

with st.sidebar:
    st.header("Settings")
    force_basic = st.toggle(
        "Force basic_rag route",
        value=False,
        help="Skip the router and advanced techniques.",
    )
    show_matrix = st.toggle(
        "Show Evaluation Matrix (LLM Judge)",
        value=True,
        help="Uses the model to score Context Relevance, Faithfulness, Answer Relevance, Correctness. Adds a bit of cost/latency.",
    )
    if st.button("Clear chat + conversation memory"):
        st.session_state.chat_history = []
        pipeline.reset_history()
        st.rerun()
    st.divider()
    total_cost = sum(c["result"]["cost"]["total_cost_usd"] for c in st.session_state.chat_history)
    st.metric("Session total cost", f"${total_cost:.6f}")
    st.metric("Questions asked", len(st.session_state.chat_history))


def render_route_badge(result: dict) -> str:
    route = result["route"]
    techniques = result.get("techniques") or []
    if route == "advanced_rag" and techniques:
        return f"**advanced_rag** — techniques: `{', '.join(techniques)}`"
    if route == "advanced_rag":
        return "**advanced_rag**"
    return f"**{route}**"


def render_result(question: str, result: dict) -> None:
    with st.chat_message("user"):
        st.write(question)
    with st.chat_message("assistant"):
        st.write(result.get("answer") or "*(empty answer)*")
        with st.expander("Details: cost, route, retrieved sources, Matrix"):
            cost = result.get("cost") or {}
            col1, col2, col3 = st.columns(3)
            col1.metric("Cost (USD)", f"${cost.get('total_cost_usd', 0):.6f}")
            col2.metric("Latency (wall)", f"{cost.get('wall_latency_s', 0):.2f}s")
            col3.metric("LLM latency", f"{cost.get('llm_latency_s', 0):.2f}s")

            st.markdown(f"**Route:** {render_route_badge(result)}")
            reason = result.get("reason")
            if reason:
                st.caption(f"Router reason: {reason}")

            # ===== LLM-as-Judge Evaluation Matrix =====
            scores = result.get("eval_scores")
            if scores:
                st.markdown("**Evaluation Matrix (LLM Judge):**")
                m1, m2, m3, m4 = st.columns(4)
                def _fmt(v):
                    return f"{v:.2f}" if v is not None else "N/A"
                m1.metric("Context Relevance", _fmt(scores.get("context_relevance")))
                m2.metric("Answer Relevance", _fmt(scores.get("answer_relevance")))
                m3.metric("Faithfulness", _fmt(scores.get("faithfulness")))
                m4.metric("Correctness", _fmt(scores.get("correctness")))
                if scores.get("rationale"):
                    st.caption(f"Rationale: {scores.get('rationale')}")
                st.caption(f"Method: {scores.get('method', 'llm_judge')}")

            sources = result.get("retrieved_sources") or []
            if sources:
                st.markdown("**Retrieved sources:**")
                st.table(
                    [
                        {
                            "source": s["source"],
                            "page": s["page"],
                            "year": s.get("year"),
                            "score": round(s["score"], 4),
                            "chunk_id": s["chunk_id"],
                        }
                        for s in sources
                    ]
                )
                st.markdown("**Retrieved chunks (full text):**")
                for i, s in enumerate(sources, 1):
                    title = (
                        f"{i}. {s.get('source', '?')} · p.{s.get('page', '?')} · "
                        f"score={round(float(s.get('score', 0)), 4)} · `{s.get('chunk_id', '')}`"
                    )
                    with st.expander(title, expanded=(i == 1)):
                        body = (s.get("text") or "").strip()
                        if body:
                            st.text(body)
                        else:
                            st.caption("(empty chunk text)")
            else:
                st.caption("No sources retrieved (parametric / general-knowledge answer).")


# Replay history
for turn in st.session_state.chat_history:
    render_result(turn["question"], turn["result"])

question = st.chat_input("Ask a question about the manuals...")
if question:
    with st.spinner("Thinking..."):
        if force_basic:
            result = pipeline.run_basic_only(question)
        else:
            result = pipeline.run(question)

        # Run LLM Judge for the Matrix (optional)
        if show_matrix:
            try:
                judge_tracker = CostTracker()
                ctx = result.get("context") or ""
                answer = result.get("answer") or ""
                route = result.get("route") or "basic_rag"

                # When no gold reference exists in chat mode, we pass a short note
                # so the judge still scores faithfulness & relevance properly.
                # Chat mode: no gold reference. evaluate.py derives Correctness
                # from context grounding + answer relevance (not a dummy sentence).
                reference = ""

                scores = evaluate_answer(
                    question=question,
                    context=ctx,
                    answer=answer,
                    reference=reference,
                    route=route,
                    llm=pipeline.llm,
                    tracker=judge_tracker,
                )
                result["eval_scores"] = scores

                # Add judge cost to the displayed cost
                # CostTracker exposes `total_cost` (property), not total_cost_usd
                judge_cost = judge_tracker.total_cost
                if "cost" in result and isinstance(result["cost"], dict):
                    result["cost"]["total_cost_usd"] = result["cost"].get("total_cost_usd", 0) + judge_cost
            except Exception as e:
                # Fallback to heuristic scores so the Matrix never shows all zeros
                try:
                    from advanced_rag.evaluate import heuristic_scores
                    ctx = result.get("context") or ""
                    answer = result.get("answer") or ""
                    route = result.get("route") or "basic_rag"
                    reference = ""
                    scores = heuristic_scores(question, ctx, answer, reference, route)
                    scores["method"] = "heuristic_exception"
                    scores["error"] = str(e)
                    result["eval_scores"] = scores
                except Exception:
                    result["eval_scores"] = {"error": str(e), "method": "failed"}

    st.session_state.chat_history.append({"question": question, "result": result})
    st.rerun()