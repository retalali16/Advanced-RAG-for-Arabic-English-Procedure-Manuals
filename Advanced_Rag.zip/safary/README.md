# Advanced RAG: Routing, Retrieval Improvement & Evaluation

End-to-end RAG over **all three** procedure manuals:

1. Assets and Warehouse Operations Tasks and Procedures Manual
2. Central Alarm Tasks and Procedures Manual
3. Central Mail and Files Unit Procedures Manual

The system routes each question to `simple`, `basic_rag`, or `advanced_rag`, runs **only the selected techniques**, then scores Context Relevance, Faithfulness, Answer Relevance, Correctness, cost, and latency.

## Setup

```powershell
cd D:\Advancws_Rag
python -m pip install -r requirements.txt
copy .env.example .env
```

## Setup

```powershell
cd D:\Advancws_Rag
python -m pip install -r requirements.txt
copy .env.example .env
```

Optional: set `GEMINI_API_KEY` in `.env` for Gemini generation and LLM-as-judge. Without a key, the project still runs using TF-IDF (+ dense) retrieval, heuristic routing, and extractive grounded answers so the evaluation table can be produced. **Never commit a real key** — `.env` is gitignored; only put a real key there, not in `.env.example`.

### Embedding model: BAAI/bge-m3 (Arabic)

Dense retrieval runs on **BGE-M3**, loaded locally via `sentence-transformers` (`advanced_rag/embeddings_bge.py`) — not a Gemini API call. It's the default because it's multilingual/Arabic-capable, needs no API key, has no request quota, runs fully offline once cached, and — unlike an 8B decoder embedding model — is light enough (~2.3GB, 568M params) to run comfortably on CPU for a corpus this size.

Controlled by `EMBEDDING_BACKEND` in `.env`:

| Value | Backend | Notes |
|---|---|---|
| `bge_m3` (default) | Local `BAAI/bge-m3` | ~2.3GB download; CPU is fine for a few hundred chunks, GPU is faster |
| `gemini` | Google `gemini-embedding-001` API | Legacy path, needs `GEMINI_API_KEY`; kept for comparison |
| `none` | TF-IDF only | No dense embeddings at all |

Relevant `.env` knobs when `EMBEDDING_BACKEND=bge_m3`: `BGE_EMBEDDING_MODEL`, `BGE_EMBEDDING_DEVICE` (`auto`/`cuda`/`cpu`/`mps`), `BGE_EMBEDDING_BATCH_SIZE`, `BGE_EMBEDDING_MAX_SEQ_LENGTH`.

Unlike BGE v1/v1.5 (or Qwen3-Embedding), BAAI's model card states BGE-M3 needs **no instruction prefix** for either queries or documents — it's a symmetric encoder, so `store.py`/`pipeline.py` embed both the same way.

If `sentence-transformers`/`torch` aren't installed, or the model fails to load, `store.py` logs a warning and falls back to TF-IDF-only retrieval instead of crashing the run — `VectorStore.search()` already fully supports sparse-only scoring whenever no embeddings are present.

**Retired:** the old `USE_GEMINI_EMBEDDINGS` free-tier-quota workaround only applies now when you explicitly set `EMBEDDING_BACKEND=gemini`. An earlier iteration of this project used Qwen3-Embedding-8B locally; it was replaced with BGE-M3 because the 8B model's ~15GB download and decoder-model memory footprint were unnecessarily heavy for this corpus size (see Changelog).

### OCR (important for Arabic quality)

These PDFs hit a font-cmap glyph-substitution bug in `pypdf`'s native text layer — individual Arabic letters get silently swapped even though every page has a real text layer (e.g. "الايعاز" comes out as "الاقعاز"). Ingestion now renders each page to an image and OCRs it with Tesseract (`ara+eng`, `--psm 3 --oem 1`), which avoids the bug, and only falls back to `pypdf` if OCR isn't available or scores worse on a page.

Install the system OCR tools once:

```powershell
# Windows: install Tesseract (with the Arabic language pack) and poppler, then
# make sure both are on PATH. https://github.com/UB-Mannheim/tesseract/wiki
# https://github.com/oschwartz10612/poppler-windows/releases
```

```bash
# Debian/Ubuntu
sudo apt-get install -y tesseract-ocr tesseract-ocr-ara poppler-utils
```

If neither `tesseract` nor `pdftoppm` is on PATH, ingestion prints a warning and silently falls back to `pypdf` extraction (lower quality on this corpus, but the pipeline still runs). Set `USE_OCR=0` in `.env` to force the old pypdf-only behavior.

Place the three PDFs in the project root (already present) or in `data/corpus/`.

## Chunking

Structure-aware, not fixed-character-window (`advanced_rag/ingest.py`):

1. Each PDF page is split into paragraph/procedure-step units — a new unit starts at a blank line or at a numbered-step marker (`1-`, `2-]`, `3.`, `-`, `•`), matching how these manuals actually delimit steps.
2. Units are greedily packed into windows of `CHUNK_SIZE = 1100` characters (`advanced_rag/config.py`), with a `CHUNK_OVERLAP = 180`-character tail from the previous chunk carried forward for continuity.
3. A single paragraph longer than the window is only then hard-split, first by sentence boundary, and as a last resort by a raw character cut if it has no sentence boundaries at all.

This avoids the old bug where blind character slicing cut a numbered procedure step in half. Each chunk keeps its `chunk_id`, `source` PDF, `unit`, `page`, extracted `year(s)`, and `extraction_method` (`ocr`/`pypdf`) for metadata filtering (Self-Query) and citations.

## Run

```powershell
python run_eval.py
```

`run_eval.py` re-ingests (and re-OCRs) the PDFs, then re-embeds every chunk with BGE-M3, on every run. With OCR on, ingestion alone takes several minutes on a single core (roughly 5–10 seconds per page); embedding ~150-200 chunks with BGE-M3 takes on the order of a minute or two on CPU (faster on GPU). Delete/skip the ingest step by calling `advanced_rag.store.VectorStore.load()` directly once `data/index/chunks.json` already exists, if you're iterating on the pipeline rather than the corpus (it will still (re-)compute BGE-M3 embeddings unless `data/index/embeddings.npy` is already present from a prior `build()`).

Outputs:

- `outputs/RESULTS_TABLE.md` — required results table
- `outputs/evaluation.json` — answers, chunks, cost breakdown
- `outputs/route_decisions.json`
- `outputs/cost_breakdown.json`
- `reports/REPORT.md` — analysis questions 1–15
- `data/index/chunks.json` — chunk inventory with year metadata and `extraction_method` (`ocr`/`pypdf`) per chunk
- `data/index/inventory.json` — per-manual page/chunk counts and extraction-method breakdown

## Pipeline

Question → Router JSON `{route, reason, techniques}` → optional rewrite / multi-query / decomposition / HyDE / self-query → vector search (TF-IDF, fused with BGE-M3 dense embeddings by default; Gemini embeddings if `EMBEDDING_BACKEND=gemini`) → optional CRAG retry, rerank, compression → grounded Gemini (or local) generation → evaluation.

Basic RAG baseline is also forced for every question so Advanced RAG can be compared fairly.

**Local (no API key) mode**: `generate.py`'s local fallback is purely extractive — it picks and concatenates the most relevant retrieved sentences rather than composing fluent prose. That's expected and by design; set `GEMINI_API_KEY` for fluent, LLM-composed answers grounded in the same retrieved context.

## Questions & ground truth

Q1 and Q9 keep the original general-knowledge / routing intent. Q2–Q8 and Q10 are mapped onto the three manuals while preserving the intended challenges (rewrite, multi-query, decomposition, HyDE, self-query, rerank, CRAG). Every reference answer in `advanced_rag/questions.py` was checked against the OCR'd corpus text and carries a `citations` field recording the source/page(s) it was verified against, so the ground truth itself is auditable rather than a plausible-sounding guess.

## Changelog

- **Embedding backend switched to BGE-M3 (was Qwen3-Embedding-8B)**: the first local backend used Qwen3-Embedding-8B, which turned out too heavy for routine use — an 8B-parameter decoder model, ~15GB download, and it needs a GPU with real VRAM to embed quickly. Swapped to **`BAAI/bge-m3`** (568M-param encoder, ~2.3GB, runs fine on CPU for a corpus this size) in `advanced_rag/embeddings_bge.py`. Two related bugs from the Qwen version were fixed in the process, not just papered over:
  - **Deprecation warning removed**: the Qwen module passed `tokenizer_kwargs={"padding_side": "left"}`, which newer `sentence-transformers` warns is deprecated (`processor_kwargs` instead) — that flag existed only because Qwen3-Embedding is a causal/decoder model. BGE-M3 is a bidirectional encoder and needs no such setting, so it's simply not passed anymore.
  - **No more (unneeded) instruction prefix**: the Qwen module prepended `"Instruct: ...\nQuery: ..."` to every query per its model card. BGE-M3's model card explicitly says it needs no instruction prefix for either queries or documents (symmetric encoder) — `embeddings_bge.embed()` reflects that; `is_query` is kept only for interface compatibility with `llm.py`/`pipeline.py`.
  - `config.py`: `EMBEDDING_BACKEND` default changed `qwen` → `bge_m3`; `QWEN_EMBEDDING_*` settings replaced with `BGE_EMBEDDING_*`; Matryoshka truncation (`*_DIM`) now defaults to **off** since BGE-M3 wasn't published with validated MRL truncation the way Qwen3-Embedding was.
  - `llm.py`/`store.py`: `use_qwen_embeddings` → `use_bge_embeddings`; `_qwen_embed` → `_bge_embed`; index-time batch size logic updated accordingly. `pipeline.py` needed no change — it already used the backend-agnostic `use_dense_embeddings`.
  - `requirements.txt` dependencies (`sentence-transformers`, `torch`, `transformers`, `accelerate`) are unchanged — same libraries load either model, only the model name/config differ.

## Changelog (debugging pass)

- **OCR ingestion**: replaced pypdf-only extraction with Tesseract OCR + a text-quality fallback (see above). This is the root-cause fix — everything downstream (chunking, retrieval, ground truth, generation) was being fed corrupted Arabic text before this.
- **Chunking**: replaced blind character-window slicing with a chunker that splits on paragraph/numbered-step boundaries first (these manuals are step-numbered procedures) and only hard-splits a paragraph by sentence if it alone exceeds the window. Old chunks routinely cut a procedure step in half.
- **Bug fix (`llm.py`)**: the local (no-API-key) answer generator matched terms with `[a-zA-Z]{4,}` — Latin letters only — so it found essentially zero term overlap against Arabic context and fell back to "insufficient information" for nearly every document-grounded question, even with good chunks retrieved. Fixed to match `[A-Za-z\u0600-\u06FF]{3,}`, consistent with `retrieve.py`/`evaluate.py`.
- **Bug fix (`llm.py`, embeddings)**: `embed_content` was called with no error handling, so a deprecated model name (404) or a quota error (429) crashed the entire ingestion run. Now retries with backoff on 429, and falls back to TF-IDF-only retrieval (not a crash) if embeddings can't be obtained. Also fixed the default embedding model name — `text-embedding-004` was deprecated 2026-01-14 and now 404s; default is `gemini-embedding-001`. Added `USE_GEMINI_EMBEDDINGS=0` to skip Gemini embeddings entirely (keep Gemini for generation only) if free-tier quota is a problem.
- **Bilingual glossary expanded** (`bilingual.py`) with vocabulary actually confirmed in the OCR'd corpus (donations, reconciliation, dormant stock, courier liability, CCTV extraction, fire/theft alarms) so English questions retrieve the right Arabic sections.
- **Ground truth rewritten**: every reference answer in `questions.py` is now checked against real page content instead of a plausible-sounding guess. Two references changed materially: Q7 (the manuals are all dated 2026, so "after 2024" should match all three, not report insufficient documents) and Q10 (the manual's actual recovery procedure is a specific courier-liability workflow, not a generic log/trace/notify flow).
- **Evaluation methodology fix (`evaluate.py`/`reporting.py`)**: Context Relevance on the `simple` route (no retrieval executes there) used to default to `1.0`, which silently inflated the simple route's average alongside routes that actually retrieve — making a correct router decision look like a retrieval win. It's now reported as `N/A` and excluded from every average/quality calculation. The report also states explicitly that a `simple` route on Q1/Q9 is a routing success, not evidence Advanced RAG underperformed, and documents (with a code citation) that Q3's conversational-context resolution already works via `RAGPipeline.history`.
- **Security**: `.env.example` had a real-looking Gemini API key committed in plaintext; redacted to a placeholder. Rotate that key if it was ever live.
- **Dead code**: removed a no-op `if False else` ternary in `transforms.py`'s date parsing.

